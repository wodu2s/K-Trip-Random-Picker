import { StepProgress } from "@/components/layout/StepProgress";
import { Icon } from "@/components/ui/Icon";
import { DestinationHero } from "@/components/destination/DestinationHero";
import { DestinationMeta } from "@/components/destination/DestinationMeta";
import { DestinationActions } from "@/components/destination/DestinationActions";
import { HiddenPlaceCards } from "@/components/destination/HiddenPlaceCards";
import { ChallengeMissions } from "@/components/destination/ChallengeMissions";
import { DESTINATIONS, THEME_META } from "@/data/destinations";

export default async function DestinationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const destination = DESTINATIONS.find((item) => item.id === id);

  if (!destination) {
    return (
      <main className="app-screen flex items-center justify-center px-4">
        <div className="surface-card mx-auto max-w-md rounded-[20px] p-10 text-center">
          <Icon name="compass" size={42} className="mx-auto text-primary" />
          <h1 className="font-main mt-4 text-2xl text-ink">여행지를 찾을 수 없습니다.</h1>
          <p className="font-sub mt-2 text-muted">카드를 다시 골라 새로운 여행지를 확인해주세요.</p>
          <a href="/cards" className="font-main mt-6 inline-flex min-h-12 items-center rounded-xl bg-primary px-6 text-white">카드 다시 고르기</a>
        </div>
      </main>
    );
  }

  return (
    <main className="app-screen bg-[#f6f1e8]">
      <div className="mx-auto flex h-full min-h-[1240px] w-full max-w-[1440px] flex-col px-4 py-4 sm:px-6 lg:min-h-0 lg:px-8 lg:py-3">
        <StepProgress current={4} compact className="mx-auto w-full max-w-xl" />

        <div className="mt-3 grid min-h-0 flex-1 gap-4 lg:grid-cols-[1.05fr_.95fr]">
          <DestinationHero destination={destination} />

          <aside className="flex min-h-0 flex-col gap-2.5">
            <section className="short-screen-tight rounded-2xl border border-line bg-[#fffdf8] px-4 py-3.5 shadow-[0_8px_22px_rgba(26,48,76,0.05)]">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-sub text-[10px] tracking-[0.1em] text-primary">WHY THIS PLACE</p>
                  <h2 className="font-main mt-1 text-xl leading-tight text-ink">{destination.shortDescription}</h2>
                </div>
                <div className="hidden max-w-[190px] flex-wrap justify-end gap-1.5 sm:flex">
                  {destination.themes.slice(0, 3).map((theme) => (
                    <span key={theme} className="font-sub inline-flex items-center gap-1 rounded-md bg-primary/[0.07] px-2 py-1 text-[10px] text-primary">
                      <Icon name={THEME_META[theme].icon} size={12} />
                      {THEME_META[theme].label}
                    </span>
                  ))}
                </div>
              </div>
              <p className="font-sub short-screen-hide mt-1.5 line-clamp-2 text-xs leading-5 text-muted">{destination.story}</p>
            </section>

            <DestinationMeta destination={destination} />
            <ChallengeMissions destination={destination} />
            <DestinationActions destination={destination} />
            <HiddenPlaceCards places={destination.hiddenPlaces} />
          </aside>
        </div>
      </div>
    </main>
  );
}

export function generateStaticParams() {
  return DESTINATIONS.map((destination) => ({ id: destination.id }));
}
