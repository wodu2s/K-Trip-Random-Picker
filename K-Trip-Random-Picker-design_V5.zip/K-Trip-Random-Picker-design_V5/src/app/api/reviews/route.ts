import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type GooglePlace = {
  displayName?: { text?: string };
  rating?: number;
  userRatingCount?: number;
  googleMapsUri?: string;
};

type GoogleTextSearchResponse = {
  places?: GooglePlace[];
};

export async function GET(request: NextRequest) {
  const query = request.nextUrl.searchParams.get("query")?.trim();
  const fallbackRating = Number(request.nextUrl.searchParams.get("fallbackRating") ?? "0");
  const fallbackCount = Number(request.nextUrl.searchParams.get("fallbackCount") ?? "0");

  if (!query) {
    return NextResponse.json({ error: "query is required" }, { status: 400 });
  }

  const apiKey = process.env.GOOGLE_PLACES_API_KEY;
  if (!apiKey) {
    return NextResponse.json({
      rating: fallbackRating,
      reviewCount: fallbackCount,
      source: "sample",
      placeName: query,
    });
  }

  try {
    const response = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey,
        "X-Goog-FieldMask": "places.displayName,places.rating,places.userRatingCount,places.googleMapsUri",
      },
      body: JSON.stringify({
        textQuery: query,
        languageCode: "ko",
        regionCode: "KR",
        maxResultCount: 1,
      }),
      cache: "no-store",
    });

    if (!response.ok) {
      const detail = await response.text();
      console.error("Google Places API error:", response.status, detail);
      throw new Error(`Google Places API returned ${response.status}`);
    }

    const data = (await response.json()) as GoogleTextSearchResponse;
    const place = data.places?.[0];

    if (!place || typeof place.rating !== "number") {
      throw new Error("No matching place rating found");
    }

    return NextResponse.json({
      rating: place.rating,
      reviewCount: place.userRatingCount ?? 0,
      source: "google",
      placeName: place.displayName?.text ?? query,
      mapsUrl: place.googleMapsUri,
    });
  } catch (error) {
    console.error("Review lookup failed:", error);
    return NextResponse.json({
      rating: fallbackRating,
      reviewCount: fallbackCount,
      source: "sample",
      placeName: query,
    });
  }
}
