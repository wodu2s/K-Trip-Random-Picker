"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { StepProgress } from "@/components/layout/StepProgress";
import { CardDeck } from "@/components/cards/CardDeck";
import { Icon } from "@/components/ui/Icon";
import { useTravelStore } from "@/stores/travelStore";
import { recommendCards } from "@/lib/recommend";

const MAX_REDRAWS = 3;

export default function CardsPage() {
  const router = useRouter();
  const cards = useTravelStore((state) => state.cards);
  const themes = useTravelStore((state) => state.themes);
  const duration = useTravelStore((state) => state.duration);
  const setCards = useTravelStore((state) => state.setCards);
  const [mounted, setMounted] = useState(false);
  const [redrawsLeft, setRedrawsLeft] = useState(MAX_REDRAWS);

  useEffect(() => {
    setMounted(true);
    const state = useTravelStore.getState();
    if (state.cards.length === 0 || !state.duration) router.replace("/conditions");
  }, [router]);

  function handleRedraw() {
    if (redrawsLeft <= 0) return;
    const previous = cards.map((card) => card.destinationId).join(",");
    let next = recommendCards({ themes, duration });
    for (let count = 0; count < 8 && next.map((card) => card.destinationId).join(",") === previous; count += 1) {
      next = recommendCards({ themes, duration });
    }
    setCards(next);
    setRedrawsLeft((value) => value - 1);
  }

  return (
    <main className="app-screen bg-[#f6f1e8]">
      <div className="mx-auto flex h-full min-h-[980px] w-full max-w-content flex-col px-4 py-4 sm:px-6 md:px-8 lg:min-h-0 lg:py-3">
        <div className="relative">
          <StepProgress current={3} compact className="mx-auto w-full max-w-xl" />
          <button
            type="button"
            onClick={handleRedraw}
            disabled={redrawsLeft <= 0}
            className="font-main mt-3 inline-flex min-h-9 items-center gap-2 rounded-lg border border-line bg-[#fffdf8] px-3 text-sm text-ink transition-colors hover:border-primary hover:text-primary disabled:cursor-not-allowed disabled:opacity-50 sm:absolute sm:right-0 sm:top-0 sm:mt-0"
          >
            <Icon name="refresh" size={15} />
            다시 뽑기 {redrawsLeft}/{MAX_REDRAWS}
          </button>
        </div>

        <section className="flex min-h-0 flex-1 flex-col justify-center text-center lg:pt-1">
          <p className="font-sub text-xs tracking-[0.1em] text-primary">SELECT ONE</p>
          <h1 className="font-main desktop-compact-title mt-1.5 text-3xl leading-tight text-ink sm:text-4xl">
            카드 하단의 힌트만 보고 한 장을 골라보세요.
          </h1>
          <p className="font-sub mt-1.5 text-sm text-muted sm:text-base">
            카드의 목적지는 선택한 뒤에만 공개됩니다.
          </p>

          <div className="mt-4 sm:mt-5 lg:mt-[min(2.2vh,1.25rem)]">
            {mounted && cards.length > 0 ? <CardDeck /> : <div className="min-h-[360px]" aria-hidden="true" />}
          </div>

          <div className="font-sub mx-auto mt-3 flex max-w-2xl items-center justify-center gap-2 text-xs text-muted">
            <Icon name="info" size={15} className="text-primary" />
            이모지를 길게 누르거나 마우스를 올리면 힌트 이름을 확인할 수 있습니다.
          </div>
        </section>
      </div>
    </main>
  );
}
