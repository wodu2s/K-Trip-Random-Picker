import Link from "next/link";
import { Icon } from "@/components/ui/Icon";

export default function LandingPage() {
  return (
    <main className="app-screen bg-[#dcecf7]">
      <section className="relative h-full min-h-[620px] overflow-hidden lg:min-h-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/p1.png"
          alt="여행 카드와 나침반이 놓인 여행 추천 서비스 화면"
          className="absolute inset-0 h-full w-full object-cover object-[58%_center] md:object-center"
          draggable={false}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0d2c4f]/50 via-[#0d2c4f]/[0.15] to-transparent md:from-[#0d2c4f]/20" />

        <div className="relative mx-auto flex h-full max-w-content items-center px-5 py-8 sm:px-8 lg:px-10 lg:py-5">
          <div className="paper-noise max-w-[540px] rounded-[22px] border border-white/70 bg-[#fffdf8]/90 p-6 shadow-[0_22px_55px_rgba(23,52,95,0.2)] backdrop-blur-md sm:p-8 lg:p-9">
            <p className="font-sub mb-3 text-sm tracking-[0.12em] text-primary">RANDOM KOREA TRIP</p>
            <h1 className="font-main desktop-compact-title text-balance text-[2.65rem] leading-[1.12] tracking-[-0.04em] text-ink sm:text-5xl lg:text-[3.4rem]">
              검색은 잠시 멈추고,
              <br />카드 한 장을 골라봐요.
            </h1>
            <p className="font-sub mt-4 max-w-md text-base leading-7 text-muted sm:text-lg">
              기간과 취향을 선택하면 오방색 카드 다섯 장이 나타납니다. 하단의 이모지 힌트만 보고 오늘의 여행지를 골라보세요.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4">
              <Link
                href="/conditions"
                className="font-main inline-flex min-h-14 items-center gap-2 rounded-xl bg-primary px-7 text-lg text-white shadow-[0_12px_25px_rgba(23,57,95,0.25)] transition duration-300 hover:-translate-y-0.5 hover:bg-primary-dark"
              >
                여행지 뽑기
                <Icon name="arrow-right" size={18} />
              </Link>
              <span className="font-sub inline-flex items-center gap-2 text-sm text-muted">
                <Icon name="clock" size={17} className="text-primary" />
                약 1분 소요
              </span>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
