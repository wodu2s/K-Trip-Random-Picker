"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useReducedMotion } from "framer-motion";
import { StepProgress } from "@/components/layout/StepProgress";
import { ShuffleScene } from "@/components/cards/ShuffleScene";
import { Icon } from "@/components/ui/Icon";
import { useTravelStore } from "@/stores/travelStore";
import { recommendCards } from "@/lib/recommend";

const MESSAGES = [
  "선택 조건 정리 중",
  "테마와 기간을 비교하는 중",
  "여행지 후보를 섞는 중",
  "카드 다섯 장 준비 중",
] as const;

export default function ShufflePage() {
  const router = useRouter();
  const reduce = useReducedMotion();
  const [messageIndex, setMessageIndex] = useState(0);
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    const { duration, themes, setCards } = useTravelStore.getState();
    if (!duration || themes.length === 0) {
      setBlocked(true);
      router.replace("/conditions");
      return;
    }

    setCards(recommendCards({ themes, duration }));
    const total = reduce ? 1200 : 3000;
    const step = total / MESSAGES.length;
    const timers: ReturnType<typeof setTimeout>[] = [];

    MESSAGES.forEach((_, index) => {
      timers.push(setTimeout(() => setMessageIndex(index), Math.round(step * index)));
    });
    timers.push(setTimeout(() => router.replace("/cards"), total));

    return () => timers.forEach(clearTimeout);
  }, [reduce, router]);

  if (blocked) return null;

  const progress = ((messageIndex + 1) / MESSAGES.length) * 100;

  return (
    <main className="app-screen bg-[#fffdf8]">
      <div className="mx-auto flex h-full min-h-[660px] w-full max-w-content flex-col px-4 py-4 sm:px-6 md:px-8 lg:min-h-0 lg:py-3">
        <StepProgress current={2} compact className="mx-auto w-full max-w-xl" />

        <section className="flex min-h-0 flex-1 flex-col items-center justify-center text-center">
          <p className="font-sub text-xs tracking-[0.1em] text-primary">MATCHING</p>
          <h1 className="font-main desktop-compact-title mt-1.5 text-3xl leading-tight text-ink sm:text-4xl">
            여행지 카드를 섞고 있어요.
          </h1>
          <p className="font-sub mt-1.5 text-sm text-muted sm:text-base">
            고른 조건에 맞는 여행지를 우선으로 카드 순서를 매번 새롭게 구성합니다.
          </p>

          <div className="mt-1 w-full">
            <ShuffleScene />
          </div>

          <div className="w-full max-w-md">
            <div className="font-sub flex items-center justify-between text-sm">
              <span className="inline-flex items-center gap-2 text-ink">
                <Icon name="refresh" size={17} className="animate-spin text-primary [animation-duration:2.2s]" />
                {MESSAGES[messageIndex]}
              </span>
              <span className="text-muted">{Math.round(progress)}%</span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-line">
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <p role="status" aria-live="polite" className="sr-only">{MESSAGES[messageIndex]}</p>
        </section>
      </div>
    </main>
  );
}
