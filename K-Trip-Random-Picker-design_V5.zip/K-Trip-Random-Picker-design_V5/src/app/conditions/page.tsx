import { StepProgress } from "@/components/layout/StepProgress";
import { ConditionsControls } from "@/components/conditions/ConditionsControls";
import { Icon } from "@/components/ui/Icon";

export default function ConditionsPage() {
  return (
    <main className="app-screen bg-[#eaf0f6]">
      <section className="relative h-full min-h-[760px] overflow-hidden lg:min-h-0">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/p2.png"
          alt="여행 조건을 고르는 화면의 배경"
          className="absolute inset-0 hidden h-full w-full select-none object-cover object-center md:block"
          draggable={false}
        />
        <div className="absolute inset-0 bg-[#f6f1e8]/20" />

        <div className="relative mx-auto flex h-full max-w-[1536px] flex-col px-4 py-4 sm:px-6 md:px-8 lg:py-3">
          <StepProgress
            current={1}
            compact
            className="mx-auto w-full max-w-xl rounded-xl border border-white/70 bg-[#fffdf8]/[0.92] px-4 py-2.5 shadow-[0_8px_24px_rgba(26,48,76,0.08)] backdrop-blur"
          />

          <div className="mt-3 flex min-h-0 flex-1 items-center">
            <div className="surface-card mx-auto flex w-full max-w-md flex-col rounded-[20px] p-5 md:ml-[1.5%] md:mr-auto md:max-w-[500px] lg:h-[min(620px,calc(100vh-120px))] lg:p-6 xl:ml-[1.9%] xl:w-[33%] xl:max-w-none">
              <ConditionsControls />
            </div>
          </div>

          <div className="font-sub mx-auto mt-3 flex w-full max-w-xl items-center justify-center gap-2 rounded-lg bg-[#fffdf8]/[0.88] px-3 py-2 text-xs text-muted backdrop-blur lg:absolute lg:bottom-3 lg:left-1/2 lg:mt-0 lg:w-auto lg:-translate-x-1/2">
            <Icon name="info" size={15} className="text-primary" />
            선택 항목이 많을수록 카드 후보의 우선순위가 구체적으로 바뀝니다.
          </div>
        </div>
      </section>
    </main>
  );
}
