export const TRAVEL_STEPS = ["조건 설정", "추천 준비", "카드 선택", "여행지 공개"] as const;

export function StepProgress({
  current,
  className = "",
  compact = false,
}: {
  current: 1 | 2 | 3 | 4;
  className?: string;
  compact?: boolean;
}) {
  const progress = (current / TRAVEL_STEPS.length) * 100;

  return (
    <nav aria-label="진행 단계" className={`w-full ${className}`}>
      <div className={`flex items-center justify-between font-sub ${compact ? "mb-1 text-[11px]" : "mb-1.5 text-xs"}`}>
        <span className="font-main text-primary">{TRAVEL_STEPS[current - 1]}</span>
        <span className="text-muted">{current} / {TRAVEL_STEPS.length}</span>
      </div>
      <div className={`${compact ? "h-1" : "h-1.5"} overflow-hidden rounded-full bg-line`} aria-hidden="true">
        <div
          className="h-full rounded-full bg-primary transition-[width] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{ width: `${progress}%` }}
        />
      </div>
      {!compact && (
        <ol className="mt-1.5 grid grid-cols-4 gap-2">
          {TRAVEL_STEPS.map((label, index) => {
            const step = index + 1;
            const active = step <= current;
            return (
              <li
                key={label}
                aria-current={step === current ? "step" : undefined}
                className={`truncate text-center text-[10px] font-sub sm:text-[11px] ${active ? "text-ink" : "text-muted/[0.65]"}`}
              >
                {label}
              </li>
            );
          })}
        </ol>
      )}
    </nav>
  );
}
