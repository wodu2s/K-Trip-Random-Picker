"use client";

import Link from "next/link";
import { Logo } from "./Logo";
import { Icon } from "@/components/ui/Icon";

export function Header() {
  return (
    <header className="sticky top-0 z-50 h-14 border-b border-line bg-[#fffdf8]/95 backdrop-blur lg:h-[var(--header-height)]">
      <div className="mx-auto flex h-full w-full max-w-content items-center justify-between px-4 sm:px-6 lg:px-8">
        <Logo />
        <Link
          href="/conditions"
          className="font-main inline-flex min-h-9 items-center gap-2 rounded-lg border border-line bg-white px-3.5 text-sm text-ink transition-colors hover:border-primary hover:text-primary"
        >
          새 여행 뽑기
          <Icon name="arrow-right" size={16} />
        </Link>
      </div>
    </header>
  );
}
