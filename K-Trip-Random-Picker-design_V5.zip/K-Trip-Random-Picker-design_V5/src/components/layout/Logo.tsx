import Link from "next/link";
import { Icon } from "@/components/ui/Icon";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link href="/" className={`inline-flex items-center gap-2.5 ${className}`} aria-label="Pick&Go 홈">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-[#f2d677]">
        <Icon name="compass" size={18} />
      </span>
      <span className="font-main text-[20px] tracking-[-0.02em] text-ink">
        Pick<span className="text-primary">&Go</span>
      </span>
    </Link>
  );
}
