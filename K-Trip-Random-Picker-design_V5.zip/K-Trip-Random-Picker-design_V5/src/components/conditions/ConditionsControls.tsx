"use client";

import { useRouter } from "next/navigation";
import { useTravelStore } from "@/stores/travelStore";
import { THEME_META } from "@/data/destinations";
import { Icon } from "@/components/ui/Icon";
import type { Duration, ThemeKey } from "@/types/travel";

const DURATION_OPTIONS: { value: Duration; label: string; detail: string }[] = [
  { value: "day-trip", label: "당일치기", detail: "오늘 안에 다녀오기" },
  { value: "overnight", label: "1박 이상", detail: "여유 있게 머무르기" },
];

const THEME_ORDER: ThemeKey[] = ["sea", "nature", "food", "vibe", "history", "local", "activity", "etc"];

export function ConditionsControls() {
  const router = useRouter();
  const duration = useTravelStore((state) => state.duration);
  const themes = useTravelStore((state) => state.themes);
  const setDuration = useTravelStore((state) => state.setDuration);
  const toggleTheme = useTravelStore((state) => state.toggleTheme);
  const ready = Boolean(duration) && themes.length > 0;

  return (
    <div className="desktop-compact-gap flex h-full flex-col gap-4">
      <header>
        <p className="font-sub text-xs tracking-[0.1em] text-primary">TRAVEL SETTINGS</p>
        <h1 className="font-main desktop-compact-title mt-1.5 text-3xl leading-tight text-ink xl:text-[2.15rem]">어떤 여행을 떠나볼까요?</h1>
        <p className="font-sub mt-1.5 text-sm leading-5 text-muted">기간과 관심 테마를 고르면 오방색 카드 다섯 장을 준비합니다.</p>
      </header>

      <section>
        <div className="mb-2 flex items-center gap-2 text-sm text-ink">
          <Icon name="calendar" size={17} className="text-primary" />
          <span className="font-main">여행 기간</span>
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          {DURATION_OPTIONS.map((option) => {
            const active = duration === option.value;
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => setDuration(option.value)}
                aria-pressed={active}
                className={`min-h-[62px] rounded-xl border px-3 py-2 text-left transition-all duration-300 ${
                  active
                    ? "border-primary bg-primary text-white shadow-[0_8px_18px_rgba(23,57,95,0.18)]"
                    : "border-line bg-white text-ink hover:border-primary/60"
                }`}
              >
                <span className="font-main block text-base">{option.label}</span>
                <span className={`font-sub mt-0.5 block text-[11px] ${active ? "text-white/[0.78]" : "text-muted"}`}>{option.detail}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="min-h-0">
        <div className="mb-2 flex items-center gap-2 text-sm text-ink">
          <Icon name="tag" size={17} className="text-primary" />
          <span className="font-main">관심 테마</span>
          <span className="font-sub ml-auto text-[11px] text-muted">복수 선택 가능</span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {THEME_ORDER.map((key) => {
            const meta = THEME_META[key];
            const active = themes.includes(key);
            return (
              <button
                key={key}
                type="button"
                onClick={() => toggleTheme(key)}
                aria-pressed={active}
                className={`relative flex min-h-[62px] flex-col items-center justify-center gap-1 rounded-xl border px-1.5 py-1.5 text-center transition-all duration-300 ${
                  active
                    ? "border-primary bg-primary/[0.09] text-primary"
                    : "border-line bg-white text-ink hover:border-primary/50"
                }`}
              >
                <Icon name={meta.icon} size={19} />
                <span className="font-main text-[12px] leading-tight">{meta.label}</span>
                {active && (
                  <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-white">
                    <Icon name="check" size={10} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      <div className="mt-auto">
        <button
          type="button"
          onClick={() => router.push("/shuffle")}
          disabled={!ready}
          className="font-main flex min-h-[50px] w-full items-center justify-center gap-2 rounded-xl bg-accent px-5 py-3 text-lg text-[#292319] shadow-[0_8px_18px_rgba(191,146,31,0.18)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#e2b632] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none disabled:hover:translate-y-0"
        >
          <Icon name="shuffle" size={19} />
          카드 준비하기
          <Icon name="arrow-right" size={18} />
        </button>
        <p className="font-sub mt-1.5 min-h-4 text-center text-[11px] text-muted">
          {ready ? "선택한 조건을 기준으로 추천을 시작합니다." : "기간과 테마를 하나 이상 선택해주세요."}
        </p>
      </div>
    </div>
  );
}
