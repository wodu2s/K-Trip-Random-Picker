"use client";

import { useEffect, useState } from "react";
import { Icon, type IconName } from "@/components/ui/Icon";
import type { Destination } from "@/types/travel";

export function DestinationActions({ destination }: { destination: Destination }) {
  const [saved, setSaved] = useState(false);
  const [status, setStatus] = useState("");
  const [working, setWorking] = useState(false);
  const mapUrl = `https://map.kakao.com/?q=${encodeURIComponent(`${destination.region} ${destination.name}`)}`;

  useEffect(() => {
    try {
      const items = JSON.parse(window.localStorage.getItem("pickgo-saved-destinations") ?? "[]") as string[];
      setSaved(items.includes(destination.id));
    } catch {
      setSaved(false);
    }
  }, [destination.id]);

  function toggleSaved() {
    try {
      const items = JSON.parse(window.localStorage.getItem("pickgo-saved-destinations") ?? "[]") as string[];
      const next = items.includes(destination.id)
        ? items.filter((id) => id !== destination.id)
        : [...items, destination.id];
      window.localStorage.setItem("pickgo-saved-destinations", JSON.stringify(next));
      setSaved(next.includes(destination.id));
      setStatus(next.includes(destination.id) ? "이 여행지를 브라우저에 저장했습니다." : "저장을 해제했습니다.");
    } catch {
      setStatus("저장하지 못했습니다. 브라우저 저장 설정을 확인해주세요.");
    }
  }

  async function shareUrl() {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Pick&Go 추천 여행지: ${destination.name}`,
          text: `${destination.tagline} — ${destination.region}`,
          url,
        });
        setStatus("공유 메뉴를 열었습니다.");
      } else {
        await copyText(url);
        setStatus("현재 여행지 URL을 복사했습니다.");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      try {
        await copyText(url);
        setStatus("현재 여행지 URL을 복사했습니다.");
      } catch {
        setStatus("URL을 공유하지 못했습니다.");
      }
    }
  }

  async function downloadImage() {
    setWorking(true);
    setStatus("공유 이미지를 만드는 중입니다.");
    try {
      await document.fonts.ready;
      const canvas = await createShareCanvas(destination, window.location.href);
      const link = document.createElement("a");
      link.download = `PickGo_${destination.name.replace(/\s+/g, "_")}.png`;
      link.href = canvas.toDataURL("image/png");
      document.body.appendChild(link);
      link.click();
      link.remove();
      setStatus("여행 결과 이미지를 저장했습니다.");
    } catch (error) {
      console.error(error);
      setStatus("이미지를 만들지 못했습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setWorking(false);
    }
  }

  return (
    <section>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-2">
        <ActionLink href={mapUrl} icon="route" label="길찾기" primary />
        <ActionButton icon={saved ? "check" : "save"} label={saved ? "저장됨" : "여행 저장"} onClick={toggleSaved} active={saved} />
        <ActionButton icon="image" label={working ? "제작 중" : "이미지 저장"} onClick={downloadImage} disabled={working} />
        <ActionButton icon="share" label="URL 공유" onClick={shareUrl} />
      </div>
      <p className="font-sub mt-1.5 min-h-4 text-center text-[10px] text-muted" role="status" aria-live="polite">{status}</p>
    </section>
  );
}

function ActionButton({
  icon,
  label,
  onClick,
  active = false,
  disabled = false,
}: {
  icon: IconName;
  label: string;
  onClick: () => void;
  active?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={active || undefined}
      className={`font-main flex min-h-11 items-center justify-center gap-2 rounded-xl border px-3 text-sm transition hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60 ${
        active ? "border-success/30 bg-success/[0.08] text-success" : "border-line bg-[#fffdf8] text-ink hover:border-primary hover:text-primary"
      }`}
    >
      <Icon name={icon} size={17} />
      {label}
    </button>
  );
}

function ActionLink({ href, icon, label, primary = false }: { href: string; icon: IconName; label: string; primary?: boolean }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`font-main flex min-h-11 items-center justify-center gap-2 rounded-xl border px-3 text-sm transition hover:-translate-y-0.5 ${
        primary ? "border-primary bg-primary text-white hover:bg-primary-dark" : "border-line bg-[#fffdf8] text-ink"
      }`}
    >
      <Icon name={icon} size={17} />
      {label}
    </a>
  );
}

async function copyText(text: string) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  textarea.remove();
}

async function createShareCanvas(destination: Destination, url: string) {
  const canvas = document.createElement("canvas");
  canvas.width = 1080;
  canvas.height = 1350;
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas context unavailable");

  context.fillStyle = "#f6f0e3";
  context.fillRect(0, 0, canvas.width, canvas.height);

  const cardBack = await loadImage("/images/card-back-obangsaek.webp");
  context.globalAlpha = 0.2;
  context.drawImage(cardBack, 590, 45, 430, 645);
  context.globalAlpha = 1;

  context.fillStyle = "#17395f";
  roundRect(context, 60, 60, 960, 1230, 38);
  context.fill();

  context.strokeStyle = "#d7a928";
  context.lineWidth = 3;
  roundRect(context, 86, 86, 908, 1178, 28);
  context.stroke();

  context.fillStyle = "#f2d77c";
  context.font = '32px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  context.fillText("PICK&GO · RANDOM KOREA TRIP", 125, 155);

  context.fillStyle = "#ffffff";
  context.font = '82px "PickGo Jua", "BM JUA", "Malgun Gothic", sans-serif';
  drawWrappedText(context, destination.name, 125, 280, 760, 94, 2);

  context.fillStyle = "#e7edf3";
  context.font = '38px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  drawWrappedText(context, destination.tagline, 125, 400, 780, 52, 2);

  context.fillStyle = "#f2d77c";
  context.font = '29px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  context.fillText(destination.region, 125, 505);

  const emojiY = 615;
  destination.clues.forEach((clue, index) => {
    const x = 125 + index * 275;
    context.fillStyle = "rgba(255,255,255,0.09)";
    roundRect(context, x, emojiY, 225, 175, 24);
    context.fill();
    context.font = '62px "Apple Color Emoji", "Segoe UI Emoji", sans-serif';
    context.fillText(clue.emoji, x + 78, emojiY + 78);
    context.fillStyle = "#ffffff";
    context.font = '29px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
    drawWrappedText(context, clue.label, x + 22, emojiY + 130, 181, 34, 1);
  });

  context.fillStyle = "#f2d77c";
  context.font = '36px "PickGo Jua", "BM JUA", "Malgun Gothic", sans-serif';
  context.fillText("오늘의 도전 미션", 125, 865);

  context.font = '30px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  destination.missions.forEach((mission, index) => {
    const y = 930 + index * 72;
    context.fillStyle = "#d7a928";
    context.beginPath();
    context.arc(142, y - 9, 9, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = "#ffffff";
    context.fillText(mission.title, 175, y);
  });

  context.fillStyle = "#bcc8d4";
  context.font = '24px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  context.fillText("카드 한 장으로 떠나는 국내 여행", 125, 1192);
  context.fillStyle = "#ffffff";
  context.font = '22px "PickGo Gangwon All", "GangwonEduAll Light", "Malgun Gothic", sans-serif';
  drawWrappedText(context, url, 125, 1235, 800, 28, 1);

  return canvas;
}

function loadImage(src: string) {
  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error(`Failed to load ${src}`));
    image.src = src;
  });
}

function drawWrappedText(
  context: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines: number,
) {
  const words = [...text];
  let line = "";
  let lineIndex = 0;
  for (let index = 0; index < words.length; index += 1) {
    const test = line + words[index];
    if (context.measureText(test).width > maxWidth && line) {
      context.fillText(line, x, y + lineIndex * lineHeight);
      line = words[index];
      lineIndex += 1;
      if (lineIndex >= maxLines) return;
    } else {
      line = test;
    }
  }
  if (lineIndex < maxLines) context.fillText(line, x, y + lineIndex * lineHeight);
}

function roundRect(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) {
  const r = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.moveTo(x + r, y);
  context.arcTo(x + width, y, x + width, y + height, r);
  context.arcTo(x + width, y + height, x, y + height, r);
  context.arcTo(x, y + height, x, y, r);
  context.arcTo(x, y, x + width, y, r);
  context.closePath();
}
