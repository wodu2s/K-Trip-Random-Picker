"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import type { Destination } from "@/types/travel";

export function ChallengeMissions({ destination }: { destination: Destination }) {
  const storageKey = `pickgo-missions-${destination.id}`;
  const [completed, setCompleted] = useState<string[]>([]);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(storageKey);
      if (saved) setCompleted(JSON.parse(saved) as string[]);
    } catch {
      setCompleted([]);
    }
  }, [storageKey]);

  function toggle(id: string) {
    setCompleted((current) => {
      const next = current.includes(id) ? current.filter((item) => item !== id) : [...current, id];
      try {
        window.localStorage.setItem(storageKey, JSON.stringify(next));
      } catch {
        // 저장소 사용이 제한된 환경에서도 현재 화면의 체크 상태는 유지한다.
      }
      return next;
    });
  }

  const points = useMemo(
    () => destination.missions.filter((mission) => completed.includes(mission.id)).reduce((sum, mission) => sum + mission.points, 0),
    [completed, destination.missions],
  );
  const complete = destination.missions.every((mission) => completed.includes(mission.id));

  return (
    <section className="rounded-2xl border border-line bg-[#fffdf8] p-3.5 shadow-[0_8px_22px_rgba(26,48,76,0.06)] sm:p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-soft text-[#725810]">
            <Icon name="trophy" size={18} />
          </span>
          <div>
            <h2 className="font-main text-base text-ink">오늘의 도전 미션</h2>
            <p className="font-sub text-[10px] text-muted">여행 중 직접 체크해보세요.</p>
          </div>
        </div>
        <span className="font-main rounded-lg bg-primary px-2.5 py-1 text-xs text-white">{points}P</span>
      </div>

      <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-line" aria-hidden="true">
        <motion.div
          className="h-full rounded-full bg-accent"
          animate={{ width: `${(completed.length / destination.missions.length) * 100}%` }}
          transition={{ duration: 0.4 }}
        />
      </div>

      <ul className="mt-2.5 space-y-1.5">
        {destination.missions.map((mission) => {
          const checked = completed.includes(mission.id);
          return (
            <li key={mission.id}>
              <button
                type="button"
                onClick={() => toggle(mission.id)}
                aria-pressed={checked}
                className={`flex w-full items-center gap-2.5 rounded-xl border px-2.5 py-2 text-left transition ${
                  checked ? "border-success/25 bg-success/[0.07]" : "border-transparent bg-[#f7f3eb] hover:border-primary/25"
                }`}
              >
                <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${checked ? "border-success bg-success text-white" : "border-line bg-white text-muted"}`}>
                  {checked ? <Icon name="check" size={14} /> : <span className="font-sub text-[10px]">+{mission.points}</span>}
                </span>
                <span className="min-w-0 flex-1">
                  <span className={`font-main block truncate text-sm ${checked ? "text-success line-through" : "text-ink"}`}>{mission.title}</span>
                  <span className="font-sub short-screen-hide block truncate text-[10px] text-muted">{mission.detail}</span>
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      {complete && <p className="font-main mt-2 text-center text-sm text-success" role="status">오늘의 미션을 모두 완료했어요!</p>}
    </section>
  );
}
