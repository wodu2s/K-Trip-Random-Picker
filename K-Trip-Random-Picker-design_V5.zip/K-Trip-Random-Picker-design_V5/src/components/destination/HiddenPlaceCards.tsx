import { Icon } from "@/components/ui/Icon";
import type { HiddenPlace } from "@/types/travel";

export function HiddenPlaceCards({ places }: { places: HiddenPlace[] }) {
  return (
    <section className="very-short-hide rounded-2xl border border-line bg-[#fffdf8] p-3.5 shadow-[0_8px_22px_rgba(26,48,76,0.05)]">
      <div className="flex items-center gap-2">
        <Icon name="hidden" size={17} className="text-primary" />
        <h2 className="font-main text-sm text-ink">함께 둘러볼 로컬 장소</h2>
      </div>
      <ul className="mt-2.5 flex flex-wrap gap-1.5">
        {places.map((place) => (
          <li key={place.name} className="font-sub inline-flex items-center gap-1 rounded-lg bg-[#f2eee6] px-2 py-1.5 text-[10px] text-ink sm:text-[11px]">
            <span className="text-primary">•</span>
            {place.name}
            <span className="text-muted">{place.tag}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
