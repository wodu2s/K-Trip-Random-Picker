"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import type { Destination, ThemeKey } from "@/types/travel";

export function DestinationHero({ destination }: { destination: Destination }) {
  const reduce = useReducedMotion();
  const variant = sceneVariant(destination.themes[0]);

  return (
    <motion.section
      className="relative min-h-[520px] overflow-hidden rounded-[24px] bg-[#dce8f2] shadow-[0_20px_46px_rgba(26,48,76,0.16)] lg:h-full lg:min-h-0"
      initial={reduce ? false : { opacity: 0, scale: 0.975 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
    >
      <HeroArt variant={variant} />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0d2744]/[0.72] via-transparent to-[#0a213b]/[0.82]" />

      <div className="absolute inset-x-0 top-0 p-5 text-white sm:p-7 lg:p-6 xl:p-8">
        <p className="font-sub text-[11px] tracking-[0.14em] text-[#f1d981]">YOUR DESTINATION</p>
        <motion.h1
          className="font-main desktop-compact-title mt-2 text-4xl leading-[1.05] sm:text-5xl xl:text-6xl"
          initial={reduce ? false : { opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
        >
          {destination.name}
        </motion.h1>
        <p className="font-sub mt-2 text-base text-white/[0.85] sm:text-lg">{destination.tagline}</p>
        <p className="font-sub mt-3 inline-flex items-center gap-1.5 rounded-lg border border-white/20 bg-black/20 px-2.5 py-1.5 text-xs text-white/90 backdrop-blur">
          <Icon name="location" size={14} />
          {destination.region}
        </p>
      </div>

      <div className="absolute inset-x-0 bottom-0 p-4 sm:p-6 lg:p-5 xl:p-6">
        <div className="rounded-2xl border border-white/20 bg-[#0e2946]/[0.72] p-3.5 text-white shadow-lg backdrop-blur-md sm:p-4">
          <div className="flex items-center justify-between gap-3">
            <p className="font-main text-base sm:text-lg">카드 하단에 숨어 있던 힌트</p>
            {destination.isHiddenGem && (
              <span className="font-sub inline-flex items-center gap-1 rounded-md bg-[#f3d36d]/[0.15] px-2 py-1 text-[10px] text-[#f6df91]">
                <Icon name="hidden" size={13} /> 숨은 명소
              </span>
            )}
          </div>
          <ul className="mt-3 grid grid-cols-3 gap-2">
            {destination.clues.map((clue) => (
              <li key={clue.label} className="rounded-xl border border-white/[0.15] bg-white/10 px-2 py-2.5 text-center">
                <span className="block text-2xl sm:text-3xl">{clue.emoji}</span>
                <span className="font-sub mt-1 block truncate text-[10px] text-white/[0.85] sm:text-xs">{clue.label}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </motion.section>
  );
}

type SceneVariant = "sea" | "mountain" | "town";

function sceneVariant(theme: ThemeKey | undefined): SceneVariant {
  if (theme === "sea") return "sea";
  if (theme === "history" || theme === "local" || theme === "food") return "town";
  return "mountain";
}

function HeroArt({ variant }: { variant: SceneVariant }) {
  return (
    <svg viewBox="0 0 800 900" className="h-full w-full" preserveAspectRatio="xMidYMid slice" role="img" aria-label="추천 여행지 풍경 일러스트">
      <defs>
        <linearGradient id="sky-v4" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#76a9d3" />
          <stop offset="55%" stopColor="#c8ddea" />
          <stop offset="100%" stopColor="#ead9b8" />
        </linearGradient>
        <linearGradient id="water-v4" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#377aa6" />
          <stop offset="100%" stopColor="#163f63" />
        </linearGradient>
        <radialGradient id="sun-v4" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fff8e7" />
          <stop offset="65%" stopColor="#f5d799" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#f5d799" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="800" height="900" fill="url(#sky-v4)" />
      <circle cx="630" cy="225" r="130" fill="url(#sun-v4)" />
      <circle cx="630" cy="225" r="37" fill="#fff0c8" />
      <g fill="#fff" opacity="0.72">
        <ellipse cx="145" cy="185" rx="82" ry="26" />
        <ellipse cx="225" cy="200" rx="58" ry="20" />
        <ellipse cx="490" cy="130" rx="62" ry="20" />
      </g>

      {variant === "sea" && (
        <>
          <rect y="515" width="800" height="385" fill="url(#water-v4)" />
          <path d="M0 570 Q130 330 290 440 T520 500 L520 900H0Z" fill="#547b62" />
          <path d="M340 900 Q445 555 560 550 Q690 545 745 900Z" fill="#648c67" />
          <path d="M565 900 Q600 700 665 640 Q720 590 800 625 L800 900Z" fill="#406853" />
          <rect x="555" y="445" width="22" height="115" fill="#f5f2ea" />
          <rect x="555" y="445" width="22" height="19" fill="#b94848" />
          <polygon points="552,445 580,445 566,425" fill="#963b3b" />
          <path d="M280 260 q17-16 34 0 q17-16 34 0" fill="none" stroke="#4e5c65" strokeWidth="5" strokeLinecap="round" />
        </>
      )}

      {variant === "mountain" && (
        <>
          <path d="M0 585 Q155 260 330 510 T800 455 L800 900H0Z" fill="#7892a6" opacity="0.72" />
          <path d="M0 690 Q200 430 390 620 T800 590 L800 900H0Z" fill="#527760" />
          <path d="M165 900 Q355 300 570 900Z" fill="#3f654f" />
          <polygon points="382,390 315,575 455,575" fill="#315546" />
          <polygon points="382,390 352,470 415,470" fill="#edf1f2" />
          <g fill="#284a39">
            <polygon points="100,805 65,900 140,900" />
            <polygon points="100,735 72,840 132,840" />
            <polygon points="690,780 650,900 730,900" />
            <polygon points="690,710 658,825 724,825" />
          </g>
        </>
      )}

      {variant === "town" && (
        <>
          <path d="M0 610 Q210 380 420 550 T800 515 L800 900H0Z" fill="#8099aa" opacity="0.55" />
          <path d="M0 720 Q250 550 500 680 T800 645 L800 900H0Z" fill="#667f67" />
          <g fill="#342a28">
            <TownRoof cx={175} baseY={765} w={230} h={100} />
            <TownRoof cx={405} baseY={805} w={205} h={88} />
            <TownRoof cx={630} baseY={790} w={245} h={105} />
            <TownRoof cx={340} baseY={900} w={320} h={120} />
          </g>
          <rect y="875" width="800" height="25" fill="#4b3b38" />
        </>
      )}
    </svg>
  );
}

function TownRoof({ cx, baseY, w, h }: { cx: number; baseY: number; w: number; h: number }) {
  const half = w / 2;
  return (
    <path d={`M${cx - half},${baseY} Q${cx - half - 12},${baseY - 18} ${cx - half + 24},${baseY - h * 0.42} Q${cx},${baseY - h} ${cx + half - 24},${baseY - h * 0.42} Q${cx + half + 12},${baseY - 18} ${cx + half},${baseY}Z`} />
  );
}
