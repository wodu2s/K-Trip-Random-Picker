"use client";

import { useEffect, useState } from "react";
import { Icon } from "@/components/ui/Icon";
import type { Destination } from "@/types/travel";

type ReviewData = {
  rating: number;
  reviewCount: number;
  source: "google" | "sample";
};

export function DestinationMeta({ destination }: { destination: Destination }) {
  const [review, setReview] = useState<ReviewData>({
    rating: destination.rating,
    reviewCount: destination.reviewCount,
    source: "sample",
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    const params = new URLSearchParams({
      query: destination.reviewQuery,
      fallbackRating: String(destination.rating),
      fallbackCount: String(destination.reviewCount),
    });

    fetch(`/api/reviews?${params.toString()}`, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Review API request failed");
        return response.json() as Promise<ReviewData>;
      })
      .then((data) => {
        if (active) setReview(data);
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        console.error(error);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [destination]);

  const cards = [
    { icon: "clock" as const, label: "이동", value: destination.travelTimeText },
    { icon: "star" as const, label: "평점", value: loading ? "조회 중" : `${review.rating.toFixed(1)} · ${review.reviewCount.toLocaleString()}개` },
    { icon: "hidden" as const, label: "주변 추천", value: `${destination.hiddenPlaces.length}곳` },
  ];

  return (
    <section aria-label="여행지 핵심 정보" className="grid grid-cols-3 gap-2.5">
      {cards.map((card) => (
        <div key={card.label} className="short-screen-tight rounded-xl border border-line bg-[#fffdf8] px-3 py-3 shadow-[0_6px_16px_rgba(26,48,76,0.05)]">
          <div className="flex items-center gap-1.5 text-primary">
            <Icon name={card.icon} size={15} />
            <span className="font-main text-xs">{card.label}</span>
          </div>
          <p className="font-sub mt-1.5 line-clamp-2 text-[11px] leading-4 text-ink sm:text-xs">{card.value}</p>
        </div>
      ))}
    </section>
  );
}
