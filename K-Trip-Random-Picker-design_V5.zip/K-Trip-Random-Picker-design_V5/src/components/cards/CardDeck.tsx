"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { getDestinationById } from "@/data/destinations";
import { useTravelStore } from "@/stores/travelStore";
import { MysteryCard } from "./MysteryCard";

export function CardDeck() {
  const router = useRouter();
  const reduce = useReducedMotion();
  const cards = useTravelStore((state) => state.cards);
  const selectCard = useTravelStore((state) => state.selectCard);
  const reveal = useTravelStore((state) => state.reveal);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const selecting = selectedId !== null;
  const selectedCard = cards.find((card) => card.id === selectedId) ?? null;
  const selectedDestination = selectedCard ? getDestinationById(selectedCard.destinationId) : undefined;

  function handleSelect(cardId: string, destinationId: string) {
    if (selecting) return;
    setSelectedId(cardId);
    selectCard(cardId);
    timer.current = setTimeout(() => {
      reveal(destinationId);
      router.push(`/destination/${destinationId}`);
    }, reduce ? 350 : 1550);
  }

  return (
    <div className="relative">
      <div className="mx-auto grid max-w-[1060px] grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5 lg:gap-4 xl:gap-5">
        {cards.map((card, index) => {
          const selected = card.id === selectedId;
          return (
            <motion.div
              key={card.id}
              className={index === 4 ? "col-span-2 mx-auto w-[calc(50%-6px)] sm:col-span-1 sm:w-auto" : ""}
              initial={reduce ? false : { opacity: 0, y: 30, rotate: (index - 2) * 1.4 }}
              animate={
                selecting && !selected
                  ? { opacity: 0, y: 18, scale: 0.92, x: (index - 2) * 36 }
                  : { opacity: 1, y: 0, scale: 1, x: 0, rotate: 0 }
              }
              transition={{ duration: 0.62, delay: selecting ? 0 : index * 0.08, ease: [0.22, 1, 0.36, 1] }}
              style={{ visibility: selected ? "hidden" : "visible" }}
            >
              <MysteryCard
                clues={card.clues}
                index={index + 1}
                emphasize={index === 2}
                disabled={selecting}
                onSelect={() => handleSelect(card.id, card.destinationId)}
              />
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {selecting && selectedCard && (
          <motion.div
            className="fixed inset-0 z-[70] flex items-center justify-center bg-[#f6f1e8]/90 px-6 backdrop-blur-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            aria-live="polite"
          >
            <motion.div
              className="w-[230px] sm:w-[270px]"
              initial={reduce ? false : { opacity: 0, scale: 0.76, y: 32, rotate: -3 }}
              animate={{ opacity: 1, scale: 1, y: 0, rotate: 0 }}
              transition={{ duration: reduce ? 0 : 0.62, ease: [0.22, 1, 0.36, 1] }}
            >
              <MysteryCard
                clues={selectedCard.clues}
                index={0}
                destination={selectedDestination}
                disabled
                flipped
              />
              <p className="font-main mt-5 text-center text-lg text-primary">선택한 여행지를 공개합니다</p>
            </motion.div>
            <span className="sr-only">여행지를 공개하는 중입니다.</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
