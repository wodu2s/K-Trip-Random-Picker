"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";

const CARDS = [
  { x: -112, r: -11, delay: 0 },
  { x: -56, r: -5.5, delay: 0.08 },
  { x: 0, r: 0, delay: 0.16 },
  { x: 56, r: 5.5, delay: 0.24 },
  { x: 112, r: 11, delay: 0.32 },
];

function CardBack({ index }: { index: number }) {
  return (
    <div className="relative h-[177px] w-[118px] overflow-hidden rounded-[15px] border border-[#cdbd96] bg-[#f5e8c9] shadow-[0_18px_36px_rgba(31,34,35,0.22)] sm:h-[204px] sm:w-[136px]">
      <Image
        src="/images/card-back-obangsaek.webp"
        alt=""
        fill
        sizes="136px"
        className="object-cover"
        aria-hidden="true"
      />
      <span className="font-main absolute left-1/2 top-3 flex h-7 min-w-7 -translate-x-1/2 items-center justify-center rounded-full border border-[#e5cb81]/60 bg-[#102a47]/[0.85] px-1.5 text-[10px] text-[#f4df9f]">
        {String(index + 1).padStart(2, "0")}
      </span>
    </div>
  );
}

export function ShuffleScene() {
  const reduce = useReducedMotion();

  return (
    <div className="relative mx-auto flex h-[245px] w-full max-w-[620px] items-center justify-center overflow-hidden sm:h-[285px] lg:h-[min(31vh,285px)]" aria-hidden="true">
      <div className="absolute left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/[0.15] blur-3xl" />
      {CARDS.map((card, index) => (
        <div
          key={index}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ zIndex: index === 2 ? 10 : 5 - Math.abs(index - 2) }}
        >
          <motion.div
            initial={reduce ? false : { opacity: 0, x: card.x * 1.35, y: 45, rotate: card.r * 1.4, scale: 0.82 }}
            animate={
              reduce
                ? { x: card.x, y: -62, rotate: card.r, opacity: 1 }
                : {
                    x: [card.x, card.x * 0.2, card.x, card.x * 0.55, card.x],
                    y: [-62, -84, -62, -75, -62],
                    rotate: [card.r, card.r * 0.2, card.r, card.r * 0.55, card.r],
                    scale: [1, 1.03, 1, 1.018, 1],
                    opacity: 1,
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    opacity: { duration: 0.42, delay: card.delay },
                    default: { duration: 2.35, delay: card.delay, repeat: Infinity, ease: [0.22, 1, 0.36, 1] },
                  }
            }
          >
            <CardBack index={index} />
          </motion.div>
        </div>
      ))}
    </div>
  );
}
