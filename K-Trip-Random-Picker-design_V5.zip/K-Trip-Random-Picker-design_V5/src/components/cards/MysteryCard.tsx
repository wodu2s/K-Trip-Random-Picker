"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";
import type { Destination, TravelClue } from "@/types/travel";

export function MysteryCard({
  clues,
  index,
  destination,
  onSelect,
  disabled = false,
  emphasize = false,
  flipped = false,
}: {
  clues: TravelClue[];
  index: number;
  destination?: Destination;
  onSelect?: () => void;
  disabled?: boolean;
  emphasize?: boolean;
  flipped?: boolean;
}) {
  const reduce = useReducedMotion();
  const clueText = clues.map((clue) => clue.label).join(", ");

  return (
    <motion.button
      type="button"
      onClick={onSelect}
      disabled={disabled}
      aria-label={`${index > 0 ? `${index}번 ` : "선택한 "}카드. 힌트: ${clueText}`}
      whileHover={disabled || reduce ? undefined : { y: -9, scale: 1.018 }}
      whileTap={disabled || reduce ? undefined : { scale: 0.985 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={`group block w-full [perspective:1400px] disabled:cursor-default ${
        emphasize ? "lg:-translate-y-2" : ""
      }`}
    >
      <motion.div
        className="relative aspect-[2/3] w-full [transform-style:preserve-3d]"
        initial={false}
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: reduce ? 0 : 0.85, ease: [0.22, 1, 0.36, 1] }}
      >
        {/* 카드 뒷면: 사용자가 제작한 오방색 디자인 */}
        <div className="absolute inset-0 overflow-hidden rounded-[18px] border border-[#cbb98f] bg-[#f3e7c9] shadow-[0_12px_30px_rgba(38,36,32,0.16)] [backface-visibility:hidden] transition-shadow duration-300 group-hover:shadow-[0_22px_45px_rgba(38,36,32,0.24)]">
          <Image
            src="/images/card-back-obangsaek.webp"
            alt="오방색과 태극 문양으로 디자인된 여행 카드 뒷면"
            fill
            sizes="(max-width: 640px) 44vw, (max-width: 1023px) 30vw, 200px"
            className="select-none object-cover"
            priority={index <= 5}
            draggable={false}
          />

          {index > 0 && (
            <span className="font-main absolute left-1/2 top-3 flex h-8 min-w-8 -translate-x-1/2 items-center justify-center rounded-full border border-[#e6cf8b]/70 bg-[#102a47]/[0.85] px-2 text-xs text-[#f6e8bd] shadow-lg backdrop-blur-sm">
              {String(index).padStart(2, "0")}
            </span>
          )}

          {/* 이모지 힌트는 카드 하단에 고정 */}
          <div className="absolute inset-x-2.5 bottom-2.5 rounded-xl border border-[#eadcae]/[0.55] bg-[#102a47]/[0.88] px-2 py-2 shadow-[0_6px_18px_rgba(9,25,43,0.28)] backdrop-blur-md sm:inset-x-3 sm:bottom-3 sm:py-2.5">
            <div className="flex items-center justify-center gap-1.5 sm:gap-2">
              {clues.slice(0, 3).map((clue) => (
                <span
                  key={`${clue.category}-${clue.label}`}
                  title={clue.label}
                  className="flex h-8 w-8 items-center justify-center rounded-full border border-white/20 bg-white/95 text-[17px] shadow-sm sm:h-9 sm:w-9 sm:text-[19px]"
                >
                  {clue.emoji}
                </span>
              ))}
            </div>
            <span className="font-sub mt-1 block truncate text-center text-[9px] tracking-[0.08em] text-[#f4e8c8]/[0.85] sm:text-[10px]">
              이모지 힌트
            </span>
          </div>
        </div>

        {/* 선택 후 카드 앞면 */}
        <div className="absolute inset-0 overflow-hidden rounded-[18px] border border-[#d8c9a9] bg-[#fffaf0] shadow-[0_22px_50px_rgba(26,34,43,0.24)] [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="absolute inset-2 rounded-[14px] border border-[#b88c28]/[0.55]" />
          <div className="absolute inset-4 rounded-[11px] border border-[#17395f]/[0.16]" />
          <div className="relative flex h-full flex-col items-center justify-center px-5 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-[#f7df9a] shadow-lg">
              <Icon name="spark" size={25} />
            </span>
            <p className="font-sub mt-4 text-[10px] tracking-[0.14em] text-muted">YOUR DESTINATION</p>
            <h2 className="font-main mt-2 text-2xl leading-tight text-ink sm:text-3xl">
              {destination?.name ?? "여행지 공개 중"}
            </h2>
            <p className="font-sub mt-2 line-clamp-2 text-xs leading-5 text-muted sm:text-sm">
              {destination?.tagline ?? "카드가 선택되었습니다."}
            </p>
            <div className="mt-5 flex gap-2" aria-hidden="true">
              {clues.slice(0, 3).map((clue) => (
                <span key={clue.label} className="text-xl sm:text-2xl">{clue.emoji}</span>
              ))}
            </div>
          </div>
        </div>
      </motion.div>
    </motion.button>
  );
}
