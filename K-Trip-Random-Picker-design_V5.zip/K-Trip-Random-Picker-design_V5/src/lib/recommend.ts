import { DESTINATIONS } from "@/data/destinations";
import type { Duration, MysteryCardData, ThemeKey } from "@/types/travel";

function randomJitter() {
  return Math.random() * 1.5;
}

function shuffled<T>(items: T[]) {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [result[index], result[swapIndex]] = [result[swapIndex], result[index]];
  }
  return result;
}

/**
 * 선택한 테마와 여행 기간을 점수화해 후보를 정렬한 뒤 5장을 만든다.
 * 동일 조건에서도 작은 랜덤값을 더해 카드 조합과 순서가 달라진다.
 */
export function recommendCards({
  themes,
  duration,
}: {
  themes: ThemeKey[];
  duration: Duration | null;
}): MysteryCardData[] {
  const ranked = DESTINATIONS.map((destination) => {
    const themeMatches = destination.themes.filter((theme) => themes.includes(theme)).length;
    const durationMatch = duration && destination.recommendedDurations.includes(duration) ? 1 : 0;
    const score = themeMatches * 4 + durationMatch * 2 + randomJitter();
    return { destination, score, themeMatches };
  }).sort((a, b) => b.score - a.score);

  const matched = ranked.filter((item) => item.themeMatches > 0);
  const fallback = ranked.filter((item) => item.themeMatches === 0);
  const pool = [...matched, ...fallback].slice(0, 5);

  return shuffled(pool).map(({ destination }, index) => ({
    id: `card-${Date.now()}-${index + 1}`,
    destinationId: destination.id,
    clues: destination.clues,
  }));
}
