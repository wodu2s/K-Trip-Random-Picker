import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { Duration, MysteryCardData, ThemeKey, TravelTime } from "@/types/travel";

type TravelState = {
  location: string | null;
  travelTime: TravelTime | null;
  duration: Duration | null;
  themes: ThemeKey[];
  cards: MysteryCardData[];
  selectedCardId: string | null;
  revealedDestinationId: string | null;
  setLocation: (location: string | null) => void;
  setTravelTime: (t: TravelTime | null) => void;
  setDuration: (d: Duration | null) => void;
  toggleTheme: (theme: ThemeKey) => void;
  setCards: (cards: MysteryCardData[]) => void;
  selectCard: (cardId: string) => void;
  reveal: (destinationId: string) => void;
  reset: () => void;
};

const initialState = {
  location: "서울특별시 강남구",
  travelTime: null,
  duration: null,
  themes: [] as ThemeKey[],
  cards: [] as MysteryCardData[],
  selectedCardId: null,
  revealedDestinationId: null,
};

export const useTravelStore = create<TravelState>()(
  persist(
    (set) => ({
      ...initialState,
      setLocation: (location) => set({ location }),
      setTravelTime: (travelTime) => set({ travelTime }),
      setDuration: (duration) => set({ duration }),
      toggleTheme: (theme) =>
        set((state) => ({
          themes: state.themes.includes(theme)
            ? state.themes.filter((item) => item !== theme)
            : [...state.themes, theme],
        })),
      setCards: (cards) => set({ cards, selectedCardId: null, revealedDestinationId: null }),
      selectCard: (selectedCardId) => set({ selectedCardId }),
      reveal: (revealedDestinationId) => set({ revealedDestinationId }),
      reset: () => set({ ...initialState }),
    }),
    {
      name: "pickgo-travel-flow-v4",
      storage: createJSONStorage(() => localStorage),
      partialize: (state: TravelState) => ({
        location: state.location,
        travelTime: state.travelTime,
        duration: state.duration,
        themes: state.themes,
        cards: state.cards,
        selectedCardId: state.selectedCardId,
        revealedDestinationId: state.revealedDestinationId,
      }),
    },
  ),
);
