@echo off
setlocal

if "%~1"=="" goto :usage
if "%~2"=="" goto :usage

if not exist "%~1" (
  echo [ERROR] BMJUA font file not found: %~1
  exit /b 1
)

if not exist "%~2" (
  echo [ERROR] GangwonEduAll Light font file not found: %~2
  exit /b 1
)

if not exist "public\fonts" mkdir "public\fonts"
copy /Y "%~1" "public\fonts\BMJUA.ttf" >nul
copy /Y "%~2" "public\fonts\GangwonEduAll-Light.ttf" >nul

echo [OK] Font files were copied to public\fonts.
exit /b 0

:usage
echo Usage:
echo   scripts\setup-fonts.cmd "C:\path\BMJUA.ttf" "C:\path\GangwonEduAll Light.ttf"
exit /b 1
