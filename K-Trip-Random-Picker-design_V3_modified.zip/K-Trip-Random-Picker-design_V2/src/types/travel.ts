import type { IconName } from "@/components/ui/Icon";

/** 이동 가능 시간 */
export type TravelTime = "30m" | "1h" | "half-day";

/** 여행 기간 */
export type Duration = "day-trip" | "overnight";

/** 여행 테마 키 */
export type ThemeKey =
  | "sea"
  | "nature"
  | "food"
  | "vibe"
  | "history"
  | "local"
  | "activity"
  | "etc";

/** 카드 힌트의 실제 데이터 종류 */
export type ClueCategory =
  | "place"
  | "food"
  | "event"
  | "product"
  | "activity"
  | "transport";

export type TravelClue = {
  label: string;
  category: ClueCategory;
};

/** 숨겨진 로컬 명소 */
export type HiddenPlace = {
  name: string;
  tag: string;
};

/** 여행지 데이터 */
export type Destination = {
  id: string;
  name: string;
  region: string;
  image: string;
  clues: TravelClue[];
  themes: ThemeKey[];
  shortDescription: string;
  tagline: string;
  story: string;
  travelTimeText: string;
  isHiddenGem: boolean;
  hiddenPlaces: HiddenPlace[];
  /** API 키가 없거나 호출 실패 시 사용하는 폴백 값 */
  rating: number;
  reviewCount: number;
  reviewQuery: string;
};

/** 카드 선택 화면에 표시할 미스터리 카드 */
export type MysteryCardData = {
  id: string;
  destinationId: string;
  clues: TravelClue[];
};

export type ThemeMeta = {
  label: string;
  icon: IconName;
};
