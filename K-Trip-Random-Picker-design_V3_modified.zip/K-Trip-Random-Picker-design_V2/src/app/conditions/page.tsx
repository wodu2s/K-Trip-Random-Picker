import { StepProgress } from "@/components/layout/StepProgress";
import { ConditionsControls } from "@/components/conditions/ConditionsControls";
import { Icon } from "@/components/ui/Icon";

export default function ConditionsPage() {
  return (
    <main className="no-page-scroll bg-[#eaf0f6]">
      <section className="relative h-full overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/p2.png"
          alt="여행 조건을 고르는 화면의 배경"
          className="absolute inset-0 hidden h-full w-full select-none object-cover object-center md:block"
          draggable={false}
        />

        <div className="relative mx-auto flex h-full max-w-[1536px] flex-col px-4 py-4 sm:px-6 md:px-8 md:py-5">
          <StepProgress current={1} className="mx-auto w-full max-w-2xl rounded-xl bg-white/[0.92] px-4 py-3 shadow-[0_8px_24px_rgba(26,48,76,0.08)] backdrop-blur" />

          <div className="mt-4 flex min-h-0 flex-1 items-center md:mt-3">
            <div className="surface-card mx-auto flex h-auto w-full max-w-md flex-col rounded-card p-5 md:ml-[1.5%] md:mr-auto md:h-[min(650px,76vh)] md:max-w-[500px] md:p-6 xl:ml-[1.9%] xl:w-[33%] xl:max-w-none xl:p-7">
              <ConditionsControls />
            </div>
          </div>

          <div className="mx-auto mt-3 flex w-full max-w-2xl items-center justify-center gap-2 rounded-lg bg-white/[0.85] px-3 py-2 text-xs font-medium text-muted backdrop-blur md:absolute md:bottom-5 md:left-1/2 md:w-auto md:-translate-x-1/2">
            <Icon name="info" size={15} className="text-primary" />
            선택 항목이 많을수록 카드 힌트가 구체적으로 바뀝니다.
          </div>
        </div>
      </section>
    </main>
  );
}
