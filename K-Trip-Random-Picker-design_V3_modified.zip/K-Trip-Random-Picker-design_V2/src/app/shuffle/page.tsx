"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useReducedMotion } from "framer-motion";
import { StepProgress } from "@/components/layout/StepProgress";
import { ShuffleScene } from "@/components/cards/ShuffleScene";
import { Icon } from "@/components/ui/Icon";
import { useTravelStore } from "@/stores/travelStore";
import { recommendCards } from "@/lib/recommend";

const MESSAGES = [
  "선택 조건 정리 중",
  "관련 장소와 먹거리 매칭 중",
  "후보 여행지 비교 중",
  "카드 다섯 장 준비 중",
] as const;

export default function ShufflePage() {
  const router = useRouter();
  const reduce = useReducedMotion();
  const [messageIndex, setMessageIndex] = useState(0);
  const [blocked, setBlocked] = useState(false);

  useEffect(() => {
    const { duration, themes, setCards } = useTravelStore.getState();
    if (!duration) {
      setBlocked(true);
      router.replace("/conditions");
      return;
    }

    setCards(recommendCards(themes));
    const total = reduce ? 1400 : 3200;
    const step = total / MESSAGES.length;
    const timers: ReturnType<typeof setTimeout>[] = [];

    MESSAGES.forEach((_, index) => {
      timers.push(setTimeout(() => setMessageIndex(index), Math.round(step * index)));
    });
    timers.push(setTimeout(() => router.replace("/cards"), total));

    return () => timers.forEach(clearTimeout);
  }, [reduce, router]);

  if (blocked) return null;

  const progress = ((messageIndex + 1) / MESSAGES.length) * 100;

  return (
    <main className="no-page-scroll bg-white">
      <div className="mx-auto flex h-full w-full max-w-content flex-col px-4 py-4 sm:px-6 md:px-8 md:py-5">
        <StepProgress current={2} className="mx-auto w-full max-w-2xl" />

        <section className="flex min-h-0 flex-1 flex-col items-center justify-center text-center">
          <p className="text-xs font-bold tracking-[0.08em] text-primary">MATCHING</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-[-0.03em] text-ink sm:text-4xl">
            여행지 카드를 준비하고 있습니다.
          </h1>
          <p className="mt-2 text-sm text-muted sm:text-base">
            선택한 테마와 연결되는 실제 장소·음식·활동을 기준으로 후보를 고릅니다.
          </p>

          <div className="mt-2 w-full">
            <ShuffleScene />
          </div>

          <div className="w-full max-w-md">
            <div className="flex items-center justify-between text-sm font-semibold">
              <span className="inline-flex items-center gap-2 text-ink">
                <Icon name="refresh" size={17} className="animate-spin text-primary [animation-duration:2.2s]" />
                {MESSAGES[messageIndex]}
              </span>
              <span className="text-muted">{Math.round(progress)}%</span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-line">
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <p role="status" aria-live="polite" className="sr-only">{MESSAGES[messageIndex]}</p>
        </section>
      </div>
    </main>
  );
}
