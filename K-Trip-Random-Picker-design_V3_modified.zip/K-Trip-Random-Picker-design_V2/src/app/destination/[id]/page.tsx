import { PageContainer } from "@/components/layout/PageContainer";
import { StepProgress } from "@/components/layout/StepProgress";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";
import { DestinationHero } from "@/components/destination/DestinationHero";
import { DestinationMeta } from "@/components/destination/DestinationMeta";
import { DestinationActions } from "@/components/destination/DestinationActions";
import { HiddenPlaceCards } from "@/components/destination/HiddenPlaceCards";
import { DESTINATIONS, THEME_META } from "@/data/destinations";

export default async function DestinationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const destination = DESTINATIONS.find((item) => item.id === id);

  if (!destination) {
    return (
      <PageContainer className="text-center">
        <div className="surface-card mx-auto max-w-md rounded-card p-10">
          <Icon name="compass" size={42} className="mx-auto text-primary" />
          <h1 className="mt-4 text-2xl font-extrabold text-ink">여행지를 찾을 수 없습니다.</h1>
          <p className="mt-2 text-muted">카드를 다시 골라 새로운 여행지를 확인해주세요.</p>
          <div className="mt-6">
            <Button href="/cards" variant="primary" size="lg">카드 다시 고르기</Button>
          </div>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer className="mx-auto max-w-5xl pb-16">
      <StepProgress current={4} className="mx-auto mb-8 max-w-2xl" />

      <DestinationHero destination={destination} />

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.15fr_.85fr]">
        <blockquote className="rounded-2xl border border-line bg-white px-6 py-6">
          <div className="flex items-center gap-2 text-primary">
            <Icon name="info" size={18} />
            <span className="text-xs font-bold tracking-[0.06em]">WHY THIS PLACE</span>
          </div>
          <p className="mt-4 text-xl font-extrabold leading-8 text-ink">{destination.shortDescription}</p>
          <p className="mt-3 text-sm leading-7 text-muted">{destination.story}</p>
        </blockquote>

        <div className="rounded-2xl border border-line bg-white px-6 py-6">
          <h2 className="text-sm font-extrabold text-ink">선택한 테마</h2>
          <div className="mt-3 flex flex-wrap gap-2">
            {destination.themes.map((theme) => (
              <span key={theme} className="inline-flex items-center gap-1.5 rounded-lg bg-primary/[0.08] px-3 py-2 text-xs font-bold text-primary">
                <Icon name={THEME_META[theme].icon} size={15} />
                {THEME_META[theme].label}
              </span>
            ))}
          </div>
          <p className="mt-4 text-xs leading-6 text-muted">
            테마와 카드 힌트가 겹치는 정도를 기준으로 후보 여행지를 구성했습니다.
          </p>
        </div>
      </div>

      <div className="mt-6">
        <DestinationMeta destination={destination} />
      </div>

      <div className="mt-8">
        <DestinationActions destination={destination} />
      </div>

      <div className="mt-12">
        <HiddenPlaceCards places={destination.hiddenPlaces} />
      </div>
    </PageContainer>
  );
}

export function generateStaticParams() {
  return DESTINATIONS.map((destination) => ({ id: destination.id }));
}
