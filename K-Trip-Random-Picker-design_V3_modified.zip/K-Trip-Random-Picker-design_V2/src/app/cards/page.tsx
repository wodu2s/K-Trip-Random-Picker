"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { StepProgress } from "@/components/layout/StepProgress";
import { CardDeck } from "@/components/cards/CardDeck";
import { Icon } from "@/components/ui/Icon";
import { useTravelStore } from "@/stores/travelStore";
import { recommendCards } from "@/lib/recommend";

const MAX_REDRAWS = 3;

export default function CardsPage() {
  const router = useRouter();
  const cards = useTravelStore((s) => s.cards);
  const themes = useTravelStore((s) => s.themes);
  const setCards = useTravelStore((s) => s.setCards);
  const [mounted, setMounted] = useState(false);
  const [redrawsLeft, setRedrawsLeft] = useState(MAX_REDRAWS);

  useEffect(() => {
    setMounted(true);
    if (useTravelStore.getState().cards.length === 0) router.replace("/conditions");
  }, [router]);

  function handleRedraw() {
    if (redrawsLeft <= 0) return;
    const previous = cards.map((card) => card.destinationId).join(",");
    let next = recommendCards(themes);
    for (let count = 0; count < 6 && next.map((card) => card.destinationId).join(",") === previous; count += 1) {
      next = recommendCards(themes);
    }
    setCards(next);
    setRedrawsLeft((value) => value - 1);
  }

  return (
    <main className="no-page-scroll bg-[#f4f6f8]">
      <div className="mx-auto flex h-full w-full max-w-content flex-col px-4 py-4 sm:px-6 md:px-8 md:py-5">
        <div className="relative">
          <StepProgress current={3} className="mx-auto w-full max-w-2xl" />
          <button
            type="button"
            onClick={handleRedraw}
            disabled={redrawsLeft <= 0}
            className="mt-3 inline-flex min-h-9 items-center gap-2 rounded-lg border border-line bg-white px-3 text-xs font-bold text-ink transition-colors hover:border-primary hover:text-primary disabled:cursor-not-allowed disabled:opacity-50 sm:absolute sm:right-0 sm:top-0 sm:mt-0"
          >
            <Icon name="refresh" size={15} />
            다시 뽑기 {redrawsLeft}/{MAX_REDRAWS}
          </button>
        </div>

        <section className="flex min-h-0 flex-1 flex-col justify-center text-center">
          <p className="text-xs font-bold tracking-[0.08em] text-primary">SELECT ONE</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-[-0.03em] text-ink sm:text-4xl">
            힌트를 보고 카드 한 장을 선택하세요.
          </h1>
          <p className="mt-2 text-sm text-muted sm:text-base">
            장소·음식·행사·상품·활동 힌트는 공개되는 여행지와 직접 연결됩니다.
          </p>

          <div className="mt-5 sm:mt-7">
            {mounted && cards.length > 0 ? <CardDeck /> : <div className="min-h-[300px]" aria-hidden="true" />}
          </div>

          <div className="mx-auto mt-4 flex max-w-2xl items-center justify-center gap-2 text-xs font-medium text-muted">
            <Icon name="info" size={15} className="text-primary" />
            여행지 이름은 선택 후 공개됩니다.
          </div>
        </section>
      </div>
    </main>
  );
}
