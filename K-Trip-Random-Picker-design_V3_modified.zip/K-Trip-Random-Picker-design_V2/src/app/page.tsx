import Link from "next/link";
import { Icon } from "@/components/ui/Icon";

export default function LandingPage() {
  return (
    <main className="no-page-scroll bg-[#dcecf7]">
      <section className="relative h-full overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/p1.png"
          alt="여행 카드와 나침반이 놓인 여행 추천 서비스 화면"
          className="absolute inset-0 h-full w-full object-cover object-[58%_center] md:object-center"
          draggable={false}
        />

        <div className="absolute inset-0 bg-gradient-to-r from-[#0d2c4f]/[0.45] via-[#0d2c4f]/[0.12] to-transparent md:from-transparent md:via-transparent" />

        <div className="relative mx-auto flex h-full max-w-content items-center px-5 sm:px-8 lg:px-10">
          <div className="max-w-[520px] rounded-2xl bg-white/[0.88] p-6 shadow-[0_18px_46px_rgba(23,52,95,0.16)] backdrop-blur-md sm:p-8 md:bg-white/[0.82] lg:p-10">
            <p className="mb-4 text-sm font-bold tracking-[0.08em] text-primary">
              RANDOM TRIP PICKER
            </p>
            <h1 className="text-balance text-4xl font-extrabold leading-[1.2] tracking-[-0.04em] text-ink sm:text-5xl">
              검색보다 빠르게,
              <br />오늘의 여행지를 고릅니다.
            </h1>
            <p className="mt-5 max-w-md text-base leading-7 text-muted sm:text-lg">
              여행 기간과 취향을 선택하면 실제 장소·음식·행사·상품 힌트로 구성된 카드 다섯 장을 제안합니다.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-4">
              <Link
                href="/conditions"
                className="inline-flex min-h-14 items-center gap-2 rounded-xl bg-primary px-7 text-base font-bold text-white shadow-[0_10px_22px_rgba(21,87,192,0.22)] transition duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 hover:bg-[#104aa5]"
              >
                여행지 뽑기
                <Icon name="arrow-right" size={18} />
              </Link>
              <span className="inline-flex items-center gap-2 text-sm font-medium text-muted">
                <Icon name="clock" size={17} className="text-primary" />
                약 1분 소요
              </span>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
