import { Icon, type IconName } from "@/components/ui/Icon";
import type { HiddenPlace } from "@/types/travel";

const TAG_STYLE: Record<string, { icon: IconName; tone: string; chip: string }> = {
  자연: { icon: "leaf", tone: "bg-[#dfece4] text-[#2f6948]", chip: "bg-[#edf5f0] text-[#2f6948]" },
  산책: { icon: "route", tone: "bg-[#e0ece5] text-[#356b4c]", chip: "bg-[#edf5f0] text-[#356b4c]" },
  전망: { icon: "camera", tone: "bg-[#e1eaf5] text-[#345e92]", chip: "bg-[#edf2f8] text-[#345e92]" },
  해변: { icon: "sea", tone: "bg-[#dcecf3] text-[#276b8d]", chip: "bg-[#ebf5f8] text-[#276b8d]" },
  카페: { icon: "coffee", tone: "bg-[#eee6dc] text-[#7a5c36]", chip: "bg-[#f5f0e9] text-[#7a5c36]" },
  골목: { icon: "map", tone: "bg-[#e9e3ef] text-[#6b4c80]", chip: "bg-[#f3eef6] text-[#6b4c80]" },
  로컬: { icon: "store", tone: "bg-[#f0e6dd] text-[#865637]", chip: "bg-[#f7f0ea] text-[#865637]" },
};

const FALLBACK = { icon: "location" as const, tone: "bg-[#e7ebef] text-[#53657a]", chip: "bg-[#f2f4f6] text-[#53657a]" };

export function HiddenPlaceCards({ places }: { places: HiddenPlace[] }) {
  return (
    <section>
      <div className="flex items-end justify-between gap-4">
        <div>
          <h2 className="flex items-center gap-2 text-xl font-extrabold text-ink">
            <Icon name="hidden" size={20} className="text-primary" />
            주변 장소 추천
          </h2>
          <p className="mt-1 text-sm text-muted">결과 여행지와 함께 둘러보기 좋은 로컬 장소입니다.</p>
        </div>
      </div>

      <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {places.map((place) => {
          const style = TAG_STYLE[place.tag] ?? FALLBACK;
          return (
            <li key={place.name} className="overflow-hidden rounded-2xl border border-line bg-white shadow-[0_8px_20px_rgba(26,48,76,0.06)]">
              <div className={`flex aspect-[4/3] items-center justify-center ${style.tone}`}>
                <Icon name={style.icon} size={42} />
              </div>
              <div className="p-3.5">
                <p className="min-h-10 text-sm font-extrabold leading-5 text-ink">{place.name}</p>
                <span className={`mt-2 inline-flex rounded-md px-2 py-1 text-[11px] font-bold ${style.chip}`}>{place.tag}</span>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
