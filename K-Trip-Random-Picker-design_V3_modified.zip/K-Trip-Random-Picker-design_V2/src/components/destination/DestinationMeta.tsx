"use client";

import { useEffect, useMemo, useState } from "react";
import { Icon } from "@/components/ui/Icon";
import type { Destination } from "@/types/travel";

type ReviewData = {
  rating: number;
  reviewCount: number;
  source: "google" | "sample";
  placeName?: string;
  mapsUrl?: string;
};

function Stars({ score }: { score: number }) {
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`5점 만점에 ${score.toFixed(1)}점`}>
      {[0, 1, 2, 3, 4].map((index) => (
        <Icon
          key={index}
          name="star"
          size={15}
          className={index < Math.round(score) ? "fill-accent text-accent" : "text-line"}
        />
      ))}
    </span>
  );
}

export function DestinationMeta({ destination }: { destination: Destination }) {
  const [review, setReview] = useState<ReviewData>({
    rating: destination.rating,
    reviewCount: destination.reviewCount,
    source: "sample",
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const controller = new AbortController();
    const params = new URLSearchParams({
      query: destination.reviewQuery,
      fallbackRating: String(destination.rating),
      fallbackCount: String(destination.reviewCount),
    });

    fetch(`/api/reviews?${params.toString()}`, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Review API request failed");
        return response.json() as Promise<ReviewData>;
      })
      .then((data) => setReview(data))
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        console.error(error);
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [destination]);

  const cards = useMemo(
    () => [
      {
        icon: "clock" as const,
        title: "예상 이동 시간",
        value: destination.travelTimeText,
        note: "대중교통 기준",
      },
      {
        icon: "star" as const,
        title: "여행자 리뷰",
        value: loading ? "조회 중" : review.rating.toFixed(1),
        note: loading
          ? "평점 데이터를 불러오고 있습니다."
          : `${review.reviewCount.toLocaleString()}개 리뷰 · ${review.source === "google" ? "Google Maps" : "샘플 데이터"}`,
        stars: loading ? undefined : review.rating,
      },
      {
        icon: "tag" as const,
        title: "힌트 연결",
        value: `${destination.clues.length}개`,
        note: "장소·음식·상품 등",
      },
      {
        icon: "hidden" as const,
        title: "추가 추천",
        value: `${destination.hiddenPlaces.length}곳`,
        note: "주변 로컬 명소",
      },
    ],
    [destination, loading, review],
  );

  return (
    <section aria-label="여행지 정보">
      <ul className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((card) => (
          <li key={card.title} className="rounded-2xl border border-line bg-white p-4 shadow-[0_8px_22px_rgba(26,48,76,0.06)]">
            <div className="flex items-center gap-2 text-primary">
              <Icon name={card.icon} size={17} />
              <span className="text-xs font-bold text-muted">{card.title}</span>
            </div>
            <p className="mt-3 text-xl font-extrabold tracking-[-0.02em] text-ink">{card.value}</p>
            {card.stars !== undefined && <div className="mt-1"><Stars score={card.stars} /></div>}
            <p className="mt-1 text-[11px] leading-5 text-muted">{card.note}</p>
          </li>
        ))}
      </ul>
      {review.source === "sample" && !loading && (
        <p className="mt-2 flex items-center justify-end gap-1.5 text-[11px] text-muted">
          <Icon name="info" size={13} />
          GOOGLE_PLACES_API_KEY를 설정하면 실제 리뷰 평점으로 자동 전환됩니다.
        </p>
      )}
    </section>
  );
}
