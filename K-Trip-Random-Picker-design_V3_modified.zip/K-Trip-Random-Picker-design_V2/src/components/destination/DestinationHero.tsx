"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Icon, type IconName } from "@/components/ui/Icon";
import type { ClueCategory, Destination, ThemeKey } from "@/types/travel";

const CLUE_META: Record<ClueCategory, { label: string; icon: IconName }> = {
  place: { label: "장소", icon: "location" },
  food: { label: "음식", icon: "food" },
  event: { label: "행사·계절", icon: "event" },
  product: { label: "지역 상품", icon: "package" },
  activity: { label: "활동", icon: "route" },
  transport: { label: "교통", icon: "ship" },
};

export function DestinationHero({ destination }: { destination: Destination }) {
  const reduce = useReducedMotion();
  const variant = sceneVariant(destination.themes[0]);

  return (
    <section>
      <div className="text-center">
        <p className="text-xs font-bold tracking-[0.08em] text-primary">YOUR DESTINATION</p>
        <motion.h1
          className="mt-2 text-4xl font-extrabold tracking-[-0.04em] text-ink sm:text-6xl"
          initial={reduce ? false : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        >
          {destination.name}
        </motion.h1>
        <p className="mt-2 text-base font-semibold text-muted sm:text-lg">{destination.tagline}</p>
      </div>

      <motion.div
        className="relative mx-auto mt-6 aspect-[16/9] w-full overflow-hidden rounded-[22px] bg-[#dce8f2] shadow-[0_18px_44px_rgba(26,48,76,0.14)]"
        initial={reduce ? false : { opacity: 0, scale: 0.975 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
      >
        <HeroArt variant={variant} />
        <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-[#10253f]/[0.70] to-transparent" />

        <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-end justify-between gap-3 text-white">
          <div>
            <p className="text-sm font-bold">{destination.shortDescription}</p>
            <p className="mt-1 flex items-center gap-1.5 text-xs text-white/80">
              <Icon name="location" size={14} />
              {destination.region}
            </p>
          </div>
          {destination.isHiddenGem && (
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-white/25 bg-[#10253f]/[0.55] px-3 py-2 text-xs font-bold backdrop-blur">
              <Icon name="hidden" size={15} />
              숨은 명소
            </span>
          )}
        </div>
      </motion.div>

      <div className="mt-5 rounded-2xl border border-line bg-white p-4 sm:p-5">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-sm font-extrabold text-ink">카드 힌트와 결과 연결</h2>
          <span className="text-[11px] font-medium text-muted">선택한 카드의 3개 단서</span>
        </div>
        <ul className="mt-3 grid gap-2 sm:grid-cols-3">
          {destination.clues.map((clue) => {
            const meta = CLUE_META[clue.category];
            return (
              <li key={`${clue.category}-${clue.label}`} className="flex items-center gap-3 rounded-xl bg-[#f6f8fa] px-3 py-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <Icon name={meta.icon} size={18} />
                </span>
                <span className="min-w-0 text-left">
                  <span className="block text-[10px] font-bold text-muted">{meta.label}</span>
                  <span className="block truncate text-sm font-extrabold text-ink">{clue.label}</span>
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

type SceneVariant = "sea" | "mountain" | "town";

function sceneVariant(theme: ThemeKey | undefined): SceneVariant {
  if (theme === "sea") return "sea";
  if (theme === "history" || theme === "local" || theme === "food") return "town";
  return "mountain";
}

function HeroArt({ variant }: { variant: SceneVariant }) {
  return (
    <svg viewBox="0 0 800 450" className="h-full w-full" preserveAspectRatio="xMidYMid slice" role="img" aria-label="추천 여행지 풍경 일러스트">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#78acd8" />
          <stop offset="58%" stopColor="#c6dbe9" />
          <stop offset="100%" stopColor="#ead9b8" />
        </linearGradient>
        <linearGradient id="water" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#377aa6" />
          <stop offset="100%" stopColor="#1e5279" />
        </linearGradient>
        <radialGradient id="sun" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fff8e7" />
          <stop offset="65%" stopColor="#f5d799" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#f5d799" stopOpacity="0" />
        </radialGradient>
      </defs>
      <rect width="800" height="450" fill="url(#sky)" />
      <circle cx="630" cy="150" r="115" fill="url(#sun)" />
      <circle cx="630" cy="150" r="34" fill="#fff0c8" />
      <g fill="#fff" opacity="0.75">
        <ellipse cx="160" cy="90" rx="72" ry="22" />
        <ellipse cx="220" cy="102" rx="54" ry="18" />
        <ellipse cx="500" cy="72" rx="58" ry="18" />
      </g>

      {variant === "sea" && (
        <>
          <rect y="270" width="800" height="180" fill="url(#water)" />
          <path d="M0 295 Q120 165 265 225 T480 250 L480 450H0Z" fill="#547b62" />
          <path d="M350 450 Q430 292 535 286 Q650 282 705 450Z" fill="#648c67" />
          <path d="M540 450 Q570 360 620 330 Q674 300 735 315 L800 450Z" fill="#406853" />
          <rect x="528" y="230" width="20" height="74" fill="#f5f2ea" />
          <rect x="528" y="230" width="20" height="15" fill="#b94848" />
          <polygon points="526,230 550,230 538,214" fill="#963b3b" />
          <path d="M128 450 Q150 365 177 450Z" fill="#3d4a52" />
          <path d="M212 450 Q240 340 272 450Z" fill="#4a5861" />
          <path d="M285 135 q16-15 32 0 q16-15 32 0" fill="none" stroke="#4e5c65" strokeWidth="5" strokeLinecap="round" />
        </>
      )}

      {variant === "mountain" && (
        <>
          <path d="M0 315 Q145 145 315 265 T800 230 L800 450H0Z" fill="#7892a6" opacity="0.7" />
          <path d="M0 365 Q185 235 370 330 T800 310 L800 450H0Z" fill="#527760" />
          <path d="M210 450 Q350 180 500 450Z" fill="#3f654f" />
          <polygon points="354,225 306,315 404,315" fill="#315546" />
          <polygon points="354,225 334,261 375,261" fill="#edf1f2" />
          <path d="M270 340h10v110h-10z" fill="#d8eaf2" opacity="0.85" />
          <g fill="#284a39">
            <polygon points="110,410 82,450 138,450" />
            <polygon points="110,378 88,425 132,425" />
            <polygon points="660,395 635,450 685,450" />
            <polygon points="660,362 640,420 680,420" />
          </g>
        </>
      )}

      {variant === "town" && (
        <>
          <path d="M0 310 Q200 210 400 285 T800 265 L800 450H0Z" fill="#8099aa" opacity="0.55" />
          <path d="M0 365 Q235 292 470 350 T800 332 L800 450H0Z" fill="#667f67" />
          <g fill="#342a28">
            <TownRoof cx={180} baseY={390} w={200} h={70} />
            <TownRoof cx={390} baseY={412} w={180} h={62} />
            <TownRoof cx={610} baseY={405} w={210} h={72} />
            <TownRoof cx={320} baseY={450} w={260} h={82} />
          </g>
          <rect y="438" width="800" height="12" fill="#4b3b38" />
        </>
      )}
    </svg>
  );
}

function TownRoof({ cx, baseY, w, h }: { cx: number; baseY: number; w: number; h: number }) {
  const half = w / 2;
  return (
    <path d={`M${cx - half},${baseY} Q${cx - half - 12},${baseY - 14} ${cx - half + 24},${baseY - h * 0.42} Q${cx},${baseY - h} ${cx + half - 24},${baseY - h * 0.42} Q${cx + half + 12},${baseY - 14} ${cx + half},${baseY}Z`} />
  );
}
