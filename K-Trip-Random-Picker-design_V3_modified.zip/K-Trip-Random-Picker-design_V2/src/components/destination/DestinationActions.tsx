"use client";

import { useState } from "react";
import type { Destination } from "@/types/travel";
import { Button } from "@/components/ui/Button";
import { Icon } from "@/components/ui/Icon";

export function DestinationActions({ destination }: { destination: Destination }) {
  const [saved, setSaved] = useState(false);
  const mapUrl = `https://map.kakao.com/?q=${encodeURIComponent(`${destination.region} ${destination.name}`)}`;

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Button href={mapUrl} target="_blank" rel="noopener noreferrer" variant="accent" size="lg" className="w-full">
        <Icon name="route" size={20} />
        길찾기 시작
      </Button>
      <Button variant="secondary" size="lg" className="w-full" aria-pressed={saved} onClick={() => setSaved((value) => !value)}>
        <Icon name={saved ? "check" : "save"} size={20} />
        {saved ? "저장 완료" : "여행 저장"}
      </Button>
      {saved && <p className="text-center text-sm text-success sm:col-span-2" role="status">현재 브라우저에 저장 상태를 표시했습니다.</p>}
    </div>
  );
}
