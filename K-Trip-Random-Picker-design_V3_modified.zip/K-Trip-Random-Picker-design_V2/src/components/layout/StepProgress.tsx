export const TRAVEL_STEPS = [
  "조건 설정",
  "추천 준비",
  "카드 선택",
  "여행지 공개",
] as const;

export function StepProgress({
  current,
  className = "",
}: {
  current: 1 | 2 | 3 | 4;
  className?: string;
}) {
  const progress = (current / TRAVEL_STEPS.length) * 100;

  return (
    <nav aria-label="진행 단계" className={`w-full ${className}`}>
      <div className="mb-2 flex items-center justify-between text-xs font-semibold">
        <span className="text-primary">{TRAVEL_STEPS[current - 1]}</span>
        <span className="text-muted">{current} / {TRAVEL_STEPS.length}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-line" aria-hidden="true">
        <div
          className="h-full rounded-full bg-primary transition-[width] duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{ width: `${progress}%` }}
        />
      </div>
      <ol className="mt-2 grid grid-cols-4 gap-2">
        {TRAVEL_STEPS.map((label, index) => {
          const step = index + 1;
          const active = step <= current;
          return (
            <li
              key={label}
              aria-current={step === current ? "step" : undefined}
              className={`truncate text-center text-[10px] font-medium sm:text-xs ${
                active ? "text-ink" : "text-muted/70"
              }`}
            >
              {label}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
