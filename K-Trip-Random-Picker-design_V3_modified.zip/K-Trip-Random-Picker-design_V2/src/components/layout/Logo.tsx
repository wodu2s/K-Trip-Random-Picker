import Link from "next/link";
import { Icon } from "@/components/ui/Icon";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link
      href="/"
      className={`inline-flex items-center gap-2.5 ${className}`}
      aria-label="Pick&Go 홈"
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-white">
        <Icon name="compass" size={18} />
      </span>
      <span className="text-[18px] font-extrabold tracking-[-0.02em] text-ink">
        Pick<span className="text-primary">&Go</span>
      </span>
    </Link>
  );
}
