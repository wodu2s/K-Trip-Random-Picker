"use client";

import { useRouter } from "next/navigation";
import { useTravelStore } from "@/stores/travelStore";
import { THEME_META } from "@/data/destinations";
import { Icon } from "@/components/ui/Icon";
import type { Duration, ThemeKey } from "@/types/travel";

const DURATION_OPTIONS: { value: Duration; label: string; detail: string }[] = [
  { value: "day-trip", label: "당일치기", detail: "오늘 안에 다녀오기" },
  { value: "overnight", label: "1박 이상", detail: "여유 있게 머무르기" },
];

const THEME_ORDER: ThemeKey[] = [
  "sea",
  "nature",
  "food",
  "vibe",
  "history",
  "local",
  "activity",
  "etc",
];

export function ConditionsControls() {
  const router = useRouter();
  const duration = useTravelStore((s) => s.duration);
  const themes = useTravelStore((s) => s.themes);
  const setDuration = useTravelStore((s) => s.setDuration);
  const toggleTheme = useTravelStore((s) => s.toggleTheme);

  const ready = Boolean(duration) && themes.length > 0;

  return (
    <div className="flex h-full flex-col">
      <header>
        <p className="text-xs font-bold tracking-[0.08em] text-primary">TRAVEL SETTINGS</p>
        <h1 className="mt-2 text-2xl font-extrabold tracking-[-0.03em] text-ink xl:text-3xl">
          어떤 여행을 떠나볼까요?
        </h1>
        <p className="mt-2 text-sm leading-6 text-muted">
          기간과 관심 테마를 고르면 카드 다섯 장을 준비합니다.
        </p>
      </header>

      <section className="mt-5">
        <div className="mb-2.5 flex items-center gap-2 text-sm font-bold text-ink">
          <Icon name="calendar" size={17} className="text-primary" />
          여행 기간
        </div>
        <div className="grid grid-cols-2 gap-2.5">
          {DURATION_OPTIONS.map((option) => {
            const active = duration === option.value;
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => setDuration(option.value)}
                aria-pressed={active}
                className={`min-h-[64px] rounded-xl border px-3 py-2.5 text-left transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] ${
                  active
                    ? "border-primary bg-primary text-white shadow-[0_8px_18px_rgba(21,87,192,0.18)]"
                    : "border-line bg-white text-ink hover:border-primary/60"
                }`}
              >
                <span className="block text-sm font-bold">{option.label}</span>
                <span className={`mt-1 block text-[11px] ${active ? "text-white/75" : "text-muted"}`}>
                  {option.detail}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-5">
        <div className="mb-2.5 flex items-center gap-2 text-sm font-bold text-ink">
          <Icon name="tag" size={17} className="text-primary" />
          관심 테마
          <span className="ml-auto text-[11px] font-medium text-muted">복수 선택 가능</span>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {THEME_ORDER.map((key) => {
            const meta = THEME_META[key];
            const active = themes.includes(key);
            return (
              <button
                key={key}
                type="button"
                onClick={() => toggleTheme(key)}
                aria-pressed={active}
                className={`relative flex min-h-[64px] flex-col items-center justify-center gap-1.5 rounded-xl border px-1.5 py-2 text-center transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] ${
                  active
                    ? "border-primary bg-primary/[0.08] text-primary"
                    : "border-line bg-white text-ink hover:border-primary/50"
                }`}
              >
                <Icon name={meta.icon} size={20} />
                <span className="text-[11px] font-bold leading-tight">{meta.label}</span>
                {active && (
                  <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-white">
                    <Icon name="check" size={10} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      <div className="mt-auto pt-5">
        <button
          type="button"
          onClick={() => router.push("/shuffle")}
          disabled={!ready}
          className="flex min-h-[52px] w-full items-center justify-center gap-2 rounded-xl bg-accent px-5 py-3.5 text-base font-extrabold text-[#2d2a20] shadow-[0_8px_18px_rgba(191,146,31,0.18)] transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] hover:-translate-y-0.5 hover:bg-[#e9ba3d] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none disabled:hover:translate-y-0"
        >
          <Icon name="shuffle" size={19} />
          카드 준비하기
          <Icon name="arrow-right" size={18} />
        </button>
        <p className="mt-2 min-h-4 text-center text-[11px] text-muted">
          {ready ? "선택한 조건을 기준으로 추천을 시작합니다." : "기간과 테마를 하나 이상 선택해주세요."}
        </p>
      </div>
    </div>
  );
}
