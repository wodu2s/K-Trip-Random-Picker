"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Icon, type IconName } from "@/components/ui/Icon";
import type { ClueCategory, TravelClue } from "@/types/travel";

const CATEGORY_META: Record<ClueCategory, { label: string; icon: IconName }> = {
  place: { label: "장소", icon: "location" },
  food: { label: "음식", icon: "food" },
  event: { label: "행사·계절", icon: "event" },
  product: { label: "지역 상품", icon: "package" },
  activity: { label: "활동", icon: "route" },
  transport: { label: "교통", icon: "ship" },
};

export function MysteryCard({
  clues,
  index,
  onSelect,
  disabled = false,
  emphasize = false,
  flipped = false,
}: {
  clues: TravelClue[];
  index: number;
  onSelect?: () => void;
  disabled?: boolean;
  emphasize?: boolean;
  flipped?: boolean;
}) {
  const reduce = useReducedMotion();

  return (
    <motion.button
      type="button"
      onClick={onSelect}
      disabled={disabled}
      aria-label={`${index}번 카드 선택하기`}
      whileHover={disabled || reduce ? undefined : { y: -7, scale: 1.018 }}
      whileTap={disabled || reduce ? undefined : { scale: 0.985 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className={`group block w-full [perspective:1000px] disabled:cursor-default ${
        emphasize ? "lg:-translate-y-2" : ""
      }`}
    >
      <motion.div
        className="relative aspect-[3/4] w-full [transform-style:preserve-3d]"
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: reduce ? 0 : 0.72, ease: [0.22, 1, 0.36, 1] }}
      >
        <div className="absolute inset-0 [backface-visibility:hidden]">
          <div className="h-full w-full rounded-[18px] border border-line bg-white p-3 shadow-[0_12px_28px_rgba(26,48,76,0.11)] transition-shadow duration-300 group-hover:shadow-[0_18px_38px_rgba(26,48,76,0.17)] sm:p-4">
            <div className="flex h-full flex-col">
              <div className="flex items-center justify-between border-b border-line pb-2.5">
                <span className="text-[10px] font-bold tracking-[0.16em] text-muted">TRAVEL CLUES</span>
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#15304f] text-[11px] font-bold text-white">
                  {String(index).padStart(2, "0")}
                </span>
              </div>

              <ul className="my-auto space-y-2.5 sm:space-y-3">
                {clues.slice(0, 3).map((clue) => {
                  const meta = CATEGORY_META[clue.category];
                  return (
                    <li key={`${clue.category}-${clue.label}`} className="rounded-xl border border-line bg-[#f8fafc] p-2.5 text-left sm:p-3">
                      <div className="flex items-center gap-2 text-primary">
                        <Icon name={meta.icon} size={16} />
                        <span className="text-[10px] font-bold">{meta.label}</span>
                      </div>
                      <p className="mt-1.5 truncate text-xs font-extrabold text-ink sm:text-sm">{clue.label}</p>
                    </li>
                  );
                })}
              </ul>

              <div className="flex items-center justify-between border-t border-line pt-2.5 text-[10px] font-semibold text-muted">
                <span>목적지는 선택 후 공개</span>
                <Icon name="arrow-right" size={14} />
              </div>
            </div>
          </div>
        </div>

        <div className="absolute inset-0 [backface-visibility:hidden] [transform:rotateY(180deg)]">
          <div className="relative flex h-full w-full items-center justify-center overflow-hidden rounded-[18px] bg-[#15304f] shadow-[0_18px_42px_rgba(15,35,61,0.28)]">
            <svg className="absolute inset-0 h-full w-full opacity-[0.14]" viewBox="0 0 120 160" aria-hidden="true">
              {Array.from({ length: 7 }).map((_, row) => (
                <path
                  key={row}
                  d={`M-10 ${18 + row * 24} Q20 ${2 + row * 24} 50 ${18 + row * 24} T110 ${18 + row * 24} T170 ${18 + row * 24}`}
                  fill="none"
                  stroke="white"
                  strokeWidth="2"
                />
              ))}
            </svg>
            <span className="relative flex h-16 w-16 items-center justify-center rounded-full border border-white/25 bg-white/10 text-white">
              <Icon name="compass" size={34} />
            </span>
          </div>
        </div>
      </motion.div>
    </motion.button>
  );
}
