"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { useTravelStore } from "@/stores/travelStore";
import { MysteryCard } from "./MysteryCard";

export function CardDeck() {
  const router = useRouter();
  const reduce = useReducedMotion();
  const cards = useTravelStore((s) => s.cards);
  const selectCard = useTravelStore((s) => s.selectCard);
  const reveal = useTravelStore((s) => s.reveal);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    if (timer.current) clearTimeout(timer.current);
  }, []);

  const selecting = selectedId !== null;
  const selectedCard = cards.find((card) => card.id === selectedId) ?? null;

  function handleSelect(cardId: string, destinationId: string) {
    if (selecting) return;
    setSelectedId(cardId);
    selectCard(cardId);
    timer.current = setTimeout(() => {
      reveal(destinationId);
      router.push(`/destination/${destinationId}`);
    }, reduce ? 280 : 980);
  }

  return (
    <div className="relative">
      <div className="mx-auto grid max-w-[1040px] grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-5 lg:gap-4">
        {cards.map((card, index) => {
          const selected = card.id === selectedId;
          return (
            <motion.div
              key={card.id}
              className={index === 4 ? "col-span-2 mx-auto w-[calc(50%-6px)] lg:col-span-1 lg:w-auto" : ""}
              initial={reduce ? false : { opacity: 0, y: 24 }}
              animate={
                selecting && !selected
                  ? { opacity: 0, y: 18, scale: 0.94, x: (index - 2) * 28 }
                  : { opacity: 1, y: 0, scale: 1, x: 0 }
              }
              transition={{ duration: 0.6, delay: selecting ? 0 : index * 0.07, ease: [0.22, 1, 0.36, 1] }}
              style={{ visibility: selected ? "hidden" : "visible" }}
            >
              <MysteryCard
                clues={card.clues}
                index={index + 1}
                emphasize={index === 2}
                disabled={selecting}
                onSelect={() => handleSelect(card.id, card.destinationId)}
              />
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {selecting && selectedCard && (
          <motion.div
            className="fixed inset-0 z-40 flex items-center justify-center bg-[#f4f6f8]/[0.88] px-6 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            aria-live="polite"
          >
            <motion.div
              className="w-[205px] sm:w-[230px]"
              initial={reduce ? false : { opacity: 0, scale: 0.82, y: 24 }}
              animate={{ opacity: 1, scale: 1.06, y: 0 }}
              transition={{ duration: reduce ? 0 : 0.62, ease: [0.22, 1, 0.36, 1] }}
            >
              <MysteryCard clues={selectedCard.clues} index={0} disabled flipped={!reduce} />
            </motion.div>
            <span className="sr-only">여행지를 공개하는 중입니다.</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
