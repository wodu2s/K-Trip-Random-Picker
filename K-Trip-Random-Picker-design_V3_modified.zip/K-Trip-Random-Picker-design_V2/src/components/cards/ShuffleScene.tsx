"use client";

import { motion, useReducedMotion } from "framer-motion";
import { Icon } from "@/components/ui/Icon";

const CARDS = [
  { x: -116, r: -12, delay: 0 },
  { x: -58, r: -6, delay: 0.1 },
  { x: 0, r: 0, delay: 0.2 },
  { x: 58, r: 6, delay: 0.3 },
  { x: 116, r: 12, delay: 0.4 },
];

function CardBack({ index }: { index: number }) {
  return (
    <div className="relative h-[170px] w-[118px] overflow-hidden rounded-2xl border border-white/80 bg-[#15304f] shadow-[0_18px_36px_rgba(15,35,61,0.24)] sm:h-[196px] sm:w-[136px]">
      <div className="absolute inset-2 rounded-xl border border-white/20" />
      <svg className="absolute inset-0 h-full w-full opacity-[0.14]" viewBox="0 0 120 170" aria-hidden="true">
        {Array.from({ length: 7 }).map((_, row) => (
          <path
            key={row}
            d={`M-10 ${20 + row * 24} Q20 ${4 + row * 24} 50 ${20 + row * 24} T110 ${20 + row * 24} T170 ${20 + row * 24}`}
            fill="none"
            stroke="white"
            strokeWidth="2"
          />
        ))}
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-white">
        <span className="flex h-12 w-12 items-center justify-center rounded-full border border-white/30 bg-white/10">
          <Icon name="compass" size={25} />
        </span>
      </span>
      <span className="absolute bottom-4 left-0 right-0 text-center text-[10px] font-semibold tracking-[0.2em] text-white/[0.55]">
        PICK {String(index + 1).padStart(2, "0")}
      </span>
    </div>
  );
}

export function ShuffleScene() {
  const reduce = useReducedMotion();

  return (
    <div className="relative mx-auto flex h-[300px] w-full max-w-[620px] items-center justify-center overflow-hidden sm:h-[340px]" aria-hidden="true">
      <div className="absolute left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-3xl" />

      {CARDS.map((card, index) => (
        <div
          key={index}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
          style={{ zIndex: index === 2 ? 10 : 5 - Math.abs(index - 2) }}
        >
          <motion.div
            initial={reduce ? false : { opacity: 0, x: card.x * 1.4, y: 70, rotate: card.r * 1.4, scale: 0.86 }}
            animate={
              reduce
                ? { x: card.x, y: -90, rotate: card.r, opacity: 1 }
                : {
                    x: [card.x, card.x * 0.25, card.x, card.x * 0.55, card.x],
                    y: [-90, -112, -90, -102, -90],
                    rotate: [card.r, card.r * 0.25, card.r, card.r * 0.55, card.r],
                    scale: [1, 1.035, 1, 1.02, 1],
                    opacity: 1,
                  }
            }
            transition={
              reduce
                ? { duration: 0 }
                : {
                    opacity: { duration: 0.45, delay: card.delay },
                    default: {
                      duration: 2.4,
                      delay: card.delay,
                      repeat: Infinity,
                      ease: [0.22, 1, 0.36, 1],
                    },
                  }
            }
          >
            <CardBack index={index} />
          </motion.div>
        </div>
      ))}
    </div>
  );
}
