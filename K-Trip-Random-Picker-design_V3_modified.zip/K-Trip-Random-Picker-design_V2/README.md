# Pick&Go

국내 여행지를 카드 방식으로 추천하는 Next.js 프로토타입입니다.

## 실행

```powershell
npm.cmd install
npm.cmd run dev
```

브라우저에서 `http://localhost:3000`을 엽니다.

## 실제 리뷰 평점 연결

기본 상태에서는 프로젝트 내부 샘플 평점이 표시됩니다. Google Places API (New)를 사용하려면 프로젝트 루트에 `.env.local` 파일을 만들고 서버 키를 설정합니다.

```env
GOOGLE_PLACES_API_KEY=발급받은_키
```

설정 후 개발 서버를 다시 시작합니다.

```powershell
Ctrl + C
npm.cmd run dev
```

API 연결 구조:

- `src/app/api/reviews/route.ts`: Google Places Text Search 호출
- `src/components/destination/DestinationMeta.tsx`: 리뷰 평점과 리뷰 수 표시
- API 키가 없거나 호출이 실패하면 샘플 데이터로 자동 대체

## 주요 화면

- `/`: 랜딩
- `/conditions`: 여행 기간·테마 선택
- `/shuffle`: 후보 매칭 및 카드 준비
- `/cards`: 실제 장소·음식·행사·상품 힌트 카드 선택
- `/destination/[id]`: 결과, 리뷰 평점, 주변 장소

## 디자인 변경 사항

- 장식용 이모지를 SVG 선형 아이콘으로 교체
- Noto Sans KR 기반의 절제된 타이포그래피 적용
- 1~4단계 데스크톱 화면을 뷰포트 안에 맞춤
- 단계 숫자 대신 진행률 바와 현재 단계 표시
- 카드 힌트를 장소·음식·행사·상품·활동·교통 데이터로 구조화
- 과도한 그라데이션, 둥근 모서리, 그림자와 튀는 모션을 축소
