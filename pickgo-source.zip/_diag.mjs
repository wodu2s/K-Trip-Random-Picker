const URL = "https://ck-trip-random-picker-feature-pickg.vercel.app/";
const html = await (await fetch(URL)).text();
const scripts = [...html.matchAll(/<script[^>]*src="([^"]+)"/g)].map((m) => m[1]);
console.log("script src :", scripts);
console.log("빌드됨?    :", scripts.some((s) => s.includes("/assets/")) ? "예 (빌드 산출물)" : "아니오 (소스 원본)");
